# Overview

This is a full-stack AI companion application called Salle that provides an intelligent, emotionally-aware interface for task management, creative assistance, and personal interaction. The system combines a React frontend with an Express.js backend, featuring real-time WebSocket communication, AI model integrations, and a comprehensive user management system with permissions-based access control.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The client uses a modern React architecture built with Vite, featuring:

- **Component Structure**: Modular React components organized by functionality (chat, tasks, personas, analytics)
- **State Management**: TanStack Query for server state management with real-time synchronization
- **UI Framework**: Shadcn/ui component library with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Communication**: WebSocket connection for live chat updates

## Backend Architecture

The server implements a RESTful API with WebSocket support:

- **Framework**: Express.js with TypeScript for type safety
- **Storage Layer**: Abstracted storage interface with in-memory implementation for development
- **WebSocket Server**: Real-time bidirectional communication for chat features
- **Development Setup**: Vite integration for hot reloading in development mode
- **API Structure**: RESTful endpoints for users, conversations, tasks, memories, and persona states

## Database Schema

The system uses Drizzle ORM with PostgreSQL, defining five core entities:

- **Users**: Authentication, permissions, and profile management
- **Conversations**: Chat history with metadata and message storage
- **Tasks**: Todo items with status, priority, and due date tracking
- **Memories**: AI memory system for context retention and learning
- **Persona States**: Emotional intelligence and personality state tracking

## Authentication & Permissions

- **Firebase Integration**: Configured for user authentication
- **Permission System**: Granular access control for features like memory access, creativity tools, device control, and analytics
- **User Profiles**: Multiple user support with different permission levels

## AI Integration

The system integrates multiple AI providers:

- **Anthropic Claude**: Primary AI model for conversations
- **Google Gemini**: Alternative AI model option
- **Emotional Intelligence**: Advanced emotion analysis and response adaptation
- **Memory System**: Context-aware AI that learns from interactions

# External Dependencies

## Core Services
- **Neon Database**: PostgreSQL hosting via `@neondatabase/serverless`
- **Firebase**: User authentication and project hosting
- **WebSocket**: Real-time communication for live chat

## AI Providers
- **Anthropic**: Claude AI models via `@anthropic-ai/sdk`
- **Google AI**: Gemini models via `@google/genai`

## Frontend Libraries
- **React Ecosystem**: React 18 with TypeScript, TanStack Query for state management
- **UI Components**: Shadcn/ui with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with PostCSS processing
- **Build Tools**: Vite for development and production builds

## Backend Libraries
- **Express.js**: Web framework with WebSocket support
- **Drizzle ORM**: Type-safe database operations with PostgreSQL
- **Session Management**: PostgreSQL session storage via `connect-pg-simple`
- **Development Tools**: TSX for TypeScript execution and hot reloading

## Development Tools
- **TypeScript**: Full type safety across frontend and backend
- **ESBuild**: Fast bundling for production builds
- **Replit Integration**: Development environment plugins for seamless deployment