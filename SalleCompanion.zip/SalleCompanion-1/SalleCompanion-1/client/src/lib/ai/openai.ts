import OpenAI from "openai";

// The newest OpenAI model is "gpt-5" which was released August 7, 2025
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || import.meta.env.VITE_OPENAI_API_KEY || "",
  dangerouslyAllowBrowser: true
});

export async function sendGPTMessage(message: string, context?: any): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [{ role: "user", content: message }],
    });

    return response.choices[0].message.content || '';
  } catch (error) {
    console.error('OpenAI API error:', error);
    throw new Error('Failed to get response from GPT-5');
  }
}

export async function gptAdvancedChat(message: string, systemPrompt?: string): Promise<string> {
  const messages = [];
  if (systemPrompt) {
    messages.push({ role: "system" as const, content: systemPrompt });
  }
  messages.push({ role: "user" as const, content: message });

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages,
    });

    return response.choices[0].message.content || '';
  } catch (error) {
    console.error('OpenAI advanced chat error:', error);
    throw new Error('Failed to get advanced response from GPT-5');
  }
}

export async function gptCreativeWriting(prompt: string): Promise<string> {
  return gptAdvancedChat(prompt, "You are a creative writing assistant. Help with storytelling, poetry, and creative content.");
}

export async function gptSummarize(text: string): Promise<string> {
  return sendGPTMessage(`Please summarize the following text: ${text}`);
}

export async function gptCodeGeneration(requirements: string): Promise<string> {
  return gptAdvancedChat(requirements, "You are a code generation assistant. Provide clean, well-documented code solutions.");
}

export async function gptAgentAction(task: string): Promise<string> {
  return gptAdvancedChat(task, "You are an AI agent. Break down complex tasks into actionable steps.");
}
