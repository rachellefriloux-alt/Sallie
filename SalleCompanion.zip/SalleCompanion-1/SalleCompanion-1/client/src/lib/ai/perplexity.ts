export async function callPerplexity(message: string, context?: any): Promise<string> {
  try {
    const response = await fetch('https://api.perplexity.ai/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY || import.meta.env.VITE_PERPLEXITY_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: "llama-3.1-sonar-small-128k-online",
        messages: [
          {
            role: "system",
            content: "You are Salle, an AI companion. Be helpful, empathetic, and strategic."
          },
          {
            role: "user",
            content: message
          }
        ],
        max_tokens: 1024,
        temperature: 0.2,
        top_p: 0.9,
        stream: false,
      }),
    });

    if (!response.ok) {
      throw new Error(`Perplexity API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0]?.message?.content || '';
  } catch (error) {
    console.error('Perplexity API error:', error);
    throw new Error('Failed to get response from Perplexity');
  }
}

export async function perplexityWebSearch(query: string): Promise<string> {
  return callPerplexity(`Search for current information about: ${query}`);
}

export async function perplexityMultiHopQA(question: string): Promise<string> {
  return callPerplexity(`Answer this complex question that may require multiple steps: ${question}`);
}

export async function perplexitySummarize(text: string): Promise<string> {
  return callPerplexity(`Summarize this text: ${text}`);
}

export async function perplexityDocumentAnalysis(document: string): Promise<string> {
  return callPerplexity(`Analyze this document and provide key insights: ${document}`);
}
