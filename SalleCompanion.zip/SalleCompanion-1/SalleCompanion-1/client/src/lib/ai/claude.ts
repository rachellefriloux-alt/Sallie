import Anthropic from '@anthropic-ai/sdk';

// The newest Anthropic model is "claude-sonnet-4-20250514", not "claude-3-7-sonnet-20250219"
const DEFAULT_MODEL_STR = "claude-sonnet-4-20250514";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || import.meta.env.VITE_ANTHROPIC_API_KEY || "",
});

export async function callClaude(message: string, context?: any): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      max_tokens: 1024,
      messages: [{ role: 'user', content: message }],
      model: DEFAULT_MODEL_STR,
    });

    return response.content[0].type === 'text' ? response.content[0].text : '';
  } catch (error) {
    console.error('Claude API error:', error);
    throw new Error('Failed to get response from Claude');
  }
}

export async function claudeSummarize(text: string): Promise<string> {
  const prompt = `Please summarize the following text concisely while maintaining key points:\n\n${text}`;
  return callClaude(prompt);
}

export async function claudeAdvancedReasoning(problem: string): Promise<string> {
  const prompt = `Analyze this problem step by step and provide a reasoned solution:\n\n${problem}`;
  return callClaude(prompt);
}

export async function claudeToolUse(task: string, tools: string[]): Promise<string> {
  const prompt = `Using the available tools (${tools.join(', ')}), help me accomplish this task:\n\n${task}`;
  return callClaude(prompt);
}
