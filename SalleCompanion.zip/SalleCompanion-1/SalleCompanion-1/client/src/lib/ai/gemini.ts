import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || import.meta.env.VITE_GEMINI_API_KEY || "" 
});

export async function callGemini(message: string, context?: any): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: message,
    });

    return response.text || '';
  } catch (error) {
    console.error('Gemini API error:', error);
    throw new Error('Failed to get response from Gemini');
  }
}

export async function geminiMultimodal(prompt: string, imageData?: string): Promise<string> {
  try {
    const contents: any[] = [{ text: prompt }];
    if (imageData) {
      contents.push({
        inlineData: {
          data: imageData,
          mimeType: "image/jpeg",
        },
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      contents: contents,
    });

    return response.text || '';
  } catch (error) {
    console.error('Gemini multimodal error:', error);
    throw new Error('Failed to get multimodal response from Gemini');
  }
}

export async function geminiCreativeGeneration(prompt: string): Promise<string> {
  return callGemini(`Create something creative based on this prompt: ${prompt}`);
}

export async function geminiSummarize(text: string): Promise<string> {
  return callGemini(`Please summarize this text: ${text}`);
}

export async function geminiCodeGeneration(requirements: string): Promise<string> {
  return callGemini(`Generate code for these requirements: ${requirements}`);
}
