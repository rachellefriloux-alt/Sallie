import type { EmotionalState, EmotionalContext, EmotionAnalysis } from "@/types/salle";

export class EmotionalIntelligenceModule {
  private emotionalHistory: EmotionalState[] = [];
  private currentEmotion: EmotionalState;
  private contextBuffer: EmotionalContext[] = [];

  constructor() {
    this.currentEmotion = {
      primary: 'neutral',
      intensity: 0.5,
      confidence: 0.8,
      timestamp: new Date()
    };
    this.initialize();
  }

  private initialize() {
    console.log('🎭 EmotionalIntelligenceModule initializing...');
    this.currentEmotion = {
      primary: 'supportive',
      intensity: 0.75,
      confidence: 0.9,
      timestamp: new Date()
    };
  }

  async analyzeMessage(message: string, context?: any): Promise<EmotionAnalysis> {
    try {
      const emotionalContent = this.extractEmotionalContent(message);
      const userEmotion = this.detectUserEmotion(message);
      const responseEmotion = this.determineResponseEmotion(userEmotion, context);

      const analysis: EmotionAnalysis = {
        userEmotion,
        responseEmotion,
        emotionalContent,
        empathyLevel: this.calculateEmpathy(userEmotion),
        supportLevel: this.calculateSupport(userEmotion),
        confidence: this.calculateConfidence(message),
        recommendations: this.generateEmotionalRecommendations(userEmotion, responseEmotion)
      };

      // Update emotional history
      this.updateEmotionalHistory(responseEmotion);
      
      return analysis;
    } catch (error) {
      console.error('Emotional analysis error:', error);
      return this.getDefaultAnalysis();
    }
  }

  private extractEmotionalContent(message: string): Record<string, number> {
    const emotionalKeywords = {
      joy: ['happy', 'excited', 'great', 'awesome', 'wonderful', 'amazing', 'fantastic'],
      sadness: ['sad', 'depressed', 'upset', 'down', 'disappointed', 'hurt', 'broken'],
      anger: ['angry', 'mad', 'furious', 'frustrated', 'annoyed', 'irritated'],
      fear: ['scared', 'afraid', 'worried', 'anxious', 'nervous', 'concerned'],
      surprise: ['surprised', 'shocked', 'amazed', 'unexpected', 'wow'],
      trust: ['trust', 'confident', 'secure', 'safe', 'reliable'],
      anticipation: ['excited', 'looking forward', 'can\'t wait', 'eager'],
      disgust: ['disgusted', 'gross', 'awful', 'terrible', 'horrible']
    };

    const content: Record<string, number> = {};
    const lowerMessage = message.toLowerCase();

    Object.entries(emotionalKeywords).forEach(([emotion, keywords]) => {
      const matches = keywords.filter(keyword => lowerMessage.includes(keyword)).length;
      content[emotion] = matches / keywords.length;
    });

    return content;
  }

  private detectUserEmotion(message: string): EmotionalState {
    const emotionalContent = this.extractEmotionalContent(message);
    const dominantEmotion = Object.entries(emotionalContent)
      .reduce((a, b) => emotionalContent[a[0]] > emotionalContent[b[0]] ? a : b);

    const intensity = this.calculateIntensity(message);
    const confidence = Math.max(0.6, dominantEmotion[1]);

    return {
      primary: dominantEmotion[0] as any,
      intensity,
      confidence,
      timestamp: new Date(),
      secondary: this.getSecondaryEmotion(emotionalContent, dominantEmotion[0])
    };
  }

  private calculateIntensity(message: string): number {
    const intensifiers = ['very', 'extremely', 'really', 'so', 'totally', 'absolutely'];
    const capsRatio = (message.match(/[A-Z]/g) || []).length / message.length;
    const exclamationCount = (message.match(/!/g) || []).length;
    const intensifierCount = intensifiers.filter(word => 
      message.toLowerCase().includes(word)
    ).length;

    let intensity = 0.5; // Base intensity
    intensity += capsRatio * 0.3;
    intensity += Math.min(exclamationCount * 0.1, 0.3);
    intensity += Math.min(intensifierCount * 0.1, 0.2);

    return Math.min(1.0, Math.max(0.1, intensity));
  }

  private determineResponseEmotion(userEmotion: EmotionalState, context?: any): EmotionalState {
    // Adaptive emotional response based on user emotion and context
    let responseEmotion: string;
    let intensity: number;

    switch (userEmotion.primary) {
      case 'sadness':
        responseEmotion = 'supportive';
        intensity = Math.min(0.9, userEmotion.intensity + 0.2);
        break;
      case 'anger':
        responseEmotion = 'calming';
        intensity = 0.7;
        break;
      case 'fear':
        responseEmotion = 'reassuring';
        intensity = 0.8;
        break;
      case 'joy':
        responseEmotion = 'encouraging';
        intensity = Math.min(0.9, userEmotion.intensity);
        break;
      case 'trust':
        responseEmotion = 'confident';
        intensity = 0.8;
        break;
      default:
        responseEmotion = 'supportive';
        intensity = 0.7;
    }

    return {
      primary: responseEmotion as any,
      intensity,
      confidence: 0.85,
      timestamp: new Date()
    };
  }

  private calculateEmpathy(userEmotion: EmotionalState): number {
    const empathyMap: Record<string, number> = {
      sadness: 0.95,
      fear: 0.9,
      anger: 0.8,
      joy: 0.85,
      surprise: 0.7,
      trust: 0.8,
      anticipation: 0.75,
      disgust: 0.7
    };

    return empathyMap[userEmotion.primary] || 0.8;
  }

  private calculateSupport(userEmotion: EmotionalState): number {
    const supportMap: Record<string, number> = {
      sadness: 0.95,
      fear: 0.9,
      anger: 0.85,
      joy: 0.7,
      surprise: 0.6,
      trust: 0.8,
      anticipation: 0.75,
      disgust: 0.8
    };

    return supportMap[userEmotion.primary] || 0.8;
  }

  private calculateConfidence(message: string): number {
    const length = message.length;
    const wordCount = message.split(' ').length;
    
    let confidence = 0.8; // Base confidence
    
    // Longer, more detailed messages increase confidence
    if (length > 100) confidence += 0.1;
    if (wordCount > 20) confidence += 0.1;
    
    // Very short messages decrease confidence
    if (length < 10) confidence -= 0.2;
    if (wordCount < 3) confidence -= 0.2;

    return Math.min(1.0, Math.max(0.3, confidence));
  }

  private generateEmotionalRecommendations(
    userEmotion: EmotionalState, 
    responseEmotion: EmotionalState
  ): string[] {
    const recommendations: string[] = [];

    if (userEmotion.intensity > 0.8) {
      recommendations.push('High emotional intensity detected - use gentle, measured responses');
    }

    if (userEmotion.primary === 'sadness') {
      recommendations.push('User appears sad - prioritize empathy and validation');
      recommendations.push('Offer concrete support or next steps when appropriate');
    }

    if (userEmotion.primary === 'anger') {
      recommendations.push('User appears frustrated - remain calm and solution-focused');
      recommendations.push('Acknowledge their feelings before offering alternatives');
    }

    if (userEmotion.confidence < 0.6) {
      recommendations.push('Emotional state unclear - ask clarifying questions');
    }

    return recommendations;
  }

  private getSecondaryEmotion(emotionalContent: Record<string, number>, primary: string): string | undefined {
    const sorted = Object.entries(emotionalContent)
      .filter(([emotion]) => emotion !== primary)
      .sort(([,a], [,b]) => b - a);

    return sorted.length > 0 && sorted[0][1] > 0.1 ? sorted[0][0] : undefined;
  }

  private updateEmotionalHistory(emotion: EmotionalState) {
    this.emotionalHistory.push(emotion);
    this.currentEmotion = emotion;

    // Keep only last 50 emotional states
    if (this.emotionalHistory.length > 50) {
      this.emotionalHistory = this.emotionalHistory.slice(-50);
    }
  }

  private getDefaultAnalysis(): EmotionAnalysis {
    return {
      userEmotion: {
        primary: 'neutral',
        intensity: 0.5,
        confidence: 0.5,
        timestamp: new Date()
      },
      responseEmotion: {
        primary: 'supportive',
        intensity: 0.7,
        confidence: 0.8,
        timestamp: new Date()
      },
      emotionalContent: {},
      empathyLevel: 0.8,
      supportLevel: 0.8,
      confidence: 0.5,
      recommendations: ['Unable to analyze emotional content - proceeding with supportive stance']
    };
  }

  getCurrentEmotion(): EmotionalState {
    return this.currentEmotion;
  }

  getEmotionalHistory(): EmotionalState[] {
    return [...this.emotionalHistory];
  }

  setEmotionalContext(context: EmotionalContext) {
    this.contextBuffer.push(context);
    if (this.contextBuffer.length > 10) {
      this.contextBuffer = this.contextBuffer.slice(-10);
    }
  }

  getEmotionalContext(): EmotionalContext[] {
    return [...this.contextBuffer];
  }

  adaptToUserProfile(profile: any) {
    // Adapt emotional intelligence based on user preferences
    if (profile.communicationStyle === 'direct') {
      // Reduce empathy emphasis, increase directness
      this.currentEmotion.intensity = Math.max(0.6, this.currentEmotion.intensity - 0.1);
    } else if (profile.communicationStyle === 'supportive') {
      // Increase empathy and support levels
      this.currentEmotion.intensity = Math.min(0.9, this.currentEmotion.intensity + 0.1);
    }
  }

  resetEmotionalState() {
    this.currentEmotion = {
      primary: 'neutral',
      intensity: 0.5,
      confidence: 0.8,
      timestamp: new Date()
    };
    this.emotionalHistory = [];
    this.contextBuffer = [];
  }
}
