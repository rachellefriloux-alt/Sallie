import { callClaude } from "../ai/claude";
import { sendGPTMessage } from "../ai/openai";
import { callGemini } from "../ai/gemini";
import { callPerplexity } from "../ai/perplexity";
import { callCopilot } from "../ai/copilot";

export class SallieBrain {
  private memory: Map<string, any> = new Map();
  private context: any = {};
  private currentPersona: any = {};

  constructor() {
    this.initialize();
  }

  private async initialize() {
    console.log('🧠 SallieBrain initializing...');
    this.context = {
      conversation: [],
      userState: 'neutral',
      sessionStartTime: Date.now(),
      lastInteractionTime: null
    };
  }

  async processMessage(message: string, model: string, mode: string, userId: string) {
    try {
      this.context.lastInteractionTime = Date.now();
      this.context.conversation.push({ role: 'user', content: message, timestamp: new Date() });

      // Route to appropriate AI model
      let response = '';
      switch (model) {
        case 'claude':
          response = await callClaude(message, this.context);
          break;
        case 'gpt5':
          response = await sendGPTMessage(message, this.context);
          break;
        case 'gemini':
          response = await callGemini(message, this.context);
          break;
        case 'perplexity':
          response = await callPerplexity(message, this.context);
          break;
        case 'copilot':
          response = await callCopilot(message, this.context);
          break;
        default:
          response = await callClaude(message, this.context);
      }

      // Apply persona and mode modifications
      response = this.applyPersonaFilter(response, mode);

      this.context.conversation.push({ role: 'assistant', content: response, timestamp: new Date() });
      
      return {
        content: response,
        emotion: this.determineEmotion(message, response),
        persona: this.currentPersona,
        model,
        mode
      };
    } catch (error) {
      console.error('SallieBrain processing error:', error);
      return {
        content: "I'm having trouble processing that right now. Let me try a different approach.",
        emotion: "apologetic",
        persona: this.currentPersona,
        model,
        mode
      };
    }
  }

  private applyPersonaFilter(response: string, mode: string): string {
    switch (mode) {
      case 'agent':
        return `[Agent Mode] ${response}`;
      case 'advisory':
        return `Here's my strategic perspective: ${response}`;
      case 'creative':
        return `Let's explore this creatively: ${response}`;
      case 'sisr':
        return `[SISR Analysis] ${response}`;
      default:
        return response;
    }
  }

  private determineEmotion(userMessage: string, aiResponse: string): string {
    // Simple emotion detection based on keywords
    const supportiveKeywords = ['help', 'support', 'understand', 'care'];
    const analyticalKeywords = ['analyze', 'data', 'logic', 'reason'];
    const creativeKeywords = ['create', 'imagine', 'idea', 'inspire'];

    const message = (userMessage + ' ' + aiResponse).toLowerCase();

    if (supportiveKeywords.some(word => message.includes(word))) {
      return 'supportive';
    } else if (analyticalKeywords.some(word => message.includes(word))) {
      return 'analytical';
    } else if (creativeKeywords.some(word => message.includes(word))) {
      return 'creative';
    }

    return 'supportive'; // Default emotion
  }

  setPersona(persona: any) {
    this.currentPersona = persona;
  }

  getContext() {
    return this.context;
  }

  getMemory(key: string) {
    return this.memory.get(key);
  }

  setMemory(key: string, value: any) {
    this.memory.set(key, value);
  }
}
