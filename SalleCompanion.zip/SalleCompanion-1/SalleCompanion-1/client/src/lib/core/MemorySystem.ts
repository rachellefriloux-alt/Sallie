import type { MemoryEntry, MemoryQuery, MemoryImportance, MemoryType } from "@/types/salle";

export class MemorySystem {
  private shortTermMemory: Map<string, MemoryEntry> = new Map();
  private longTermMemory: Map<string, MemoryEntry> = new Map();
  private workingMemory: MemoryEntry[] = [];
  private memoryIndex: Map<string, Set<string>> = new Map();

  constructor() {
    this.initialize();
  }

  private initialize() {
    console.log('🧠 MemorySystem initializing...');
    this.setupMemoryCategories();
  }

  private setupMemoryCategories() {
    const categories = [
      'conversation', 'preferences', 'goals', 'habits', 'relationships',
      'work', 'personal', 'learning', 'creative', 'technical'
    ];

    categories.forEach(category => {
      this.memoryIndex.set(category, new Set());
    });
  }

  async store(entry: Omit<MemoryEntry, 'id' | 'timestamp' | 'accessCount'>): Promise<string> {
    const memoryEntry: MemoryEntry = {
      ...entry,
      id: this.generateId(),
      timestamp: new Date(),
      accessCount: 0,
      lastAccessed: new Date()
    };

    // Determine storage location based on importance
    const storage = entry.importance === 'high' || entry.importance === 'critical' 
      ? this.longTermMemory 
      : this.shortTermMemory;

    storage.set(memoryEntry.id, memoryEntry);

    // Index by tags and content
    this.indexMemory(memoryEntry);

    // Add to working memory if relevant
    if (this.isWorkingMemoryRelevant(memoryEntry)) {
      this.addToWorkingMemory(memoryEntry);
    }

    console.log(`Memory stored: ${memoryEntry.id} (${entry.importance})`);
    return memoryEntry.id;
  }

  async retrieve(query: MemoryQuery): Promise<MemoryEntry[]> {
    const results: MemoryEntry[] = [];

    // Search both short-term and long-term memory
    const allMemories = new Map([...Array.from(this.shortTermMemory), ...Array.from(this.longTermMemory)]);

    for (const [id, memory] of Array.from(allMemories)) {
      if (this.matchesQuery(memory, query)) {
        // Update access statistics
        memory.accessCount++;
        memory.lastAccessed = new Date();
        results.push(memory);
      }
    }

    // Sort by relevance and recency
    return this.rankResults(results, query);
  }

  async search(searchTerm: string, limit: number = 10): Promise<MemoryEntry[]> {
    const query: MemoryQuery = {
      content: searchTerm,
      limit
    };

    return this.retrieve(query);
  }

  async getRecentMemories(count: number = 10): Promise<MemoryEntry[]> {
    const allMemories = [...Array.from(this.shortTermMemory.values()), ...Array.from(this.longTermMemory.values())];
    
    return allMemories
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, count);
  }

  async getMemoriesByType(type: MemoryType, limit: number = 20): Promise<MemoryEntry[]> {
    const query: MemoryQuery = {
      type,
      limit
    };

    return this.retrieve(query);
  }

  async getMemoriesByTag(tag: string, limit: number = 20): Promise<MemoryEntry[]> {
    const query: MemoryQuery = {
      tags: [tag],
      limit
    };

    return this.retrieve(query);
  }

  getWorkingMemory(): MemoryEntry[] {
    return [...this.workingMemory];
  }

  async consolidateMemories(): Promise<void> {
    console.log('🔄 Consolidating memories...');

    // Move important short-term memories to long-term
    for (const [id, memory] of Array.from(this.shortTermMemory)) {
      if (this.shouldPromoteToLongTerm(memory)) {
        this.longTermMemory.set(id, memory);
        this.shortTermMemory.delete(id);
        console.log(`Promoted memory to long-term: ${id}`);
      }
    }

    // Clean up old, low-importance memories
    this.cleanupOldMemories();

    // Update working memory
    this.updateWorkingMemory();
  }

  private shouldPromoteToLongTerm(memory: MemoryEntry): boolean {
    const ageInDays = (Date.now() - memory.timestamp.getTime()) / (1000 * 60 * 60 * 24);
    
    return (
      memory.accessCount > 3 ||
      memory.importance === 'high' ||
      memory.importance === 'critical' ||
      (ageInDays > 1 && memory.accessCount > 1)
    );
  }

  private cleanupOldMemories(): void {
    const maxAge = 30 * 24 * 60 * 60 * 1000; // 30 days
    const now = Date.now();

    // Clean up short-term memory
    for (const [id, memory] of Array.from(this.shortTermMemory)) {
      if (
        now - memory.timestamp.getTime() > maxAge &&
        memory.importance === 'low' &&
        memory.accessCount < 2
      ) {
        this.shortTermMemory.delete(id);
        this.removeFromIndex(memory);
      }
    }
  }

  private updateWorkingMemory(): void {
    // Keep most recent and frequently accessed memories in working memory
    const recentMemories = [...Array.from(this.shortTermMemory.values()), ...Array.from(this.longTermMemory.values())]
      .filter(memory => {
        const ageInMinutes = (Date.now() - memory.lastAccessed.getTime()) / (1000 * 60);
        return ageInMinutes < 60 || memory.accessCount > 5; // Last hour or frequently accessed
      })
      .sort((a, b) => {
        // Sort by recency and access count
        const scoreA = a.accessCount + (Date.now() - a.lastAccessed.getTime()) / (1000 * 60 * 60);
        const scoreB = b.accessCount + (Date.now() - b.lastAccessed.getTime()) / (1000 * 60 * 60);
        return scoreB - scoreA;
      })
      .slice(0, 20);

    this.workingMemory = recentMemories;
  }

  private addToWorkingMemory(memory: MemoryEntry): void {
    this.workingMemory.unshift(memory);
    
    // Keep working memory limited
    if (this.workingMemory.length > 20) {
      this.workingMemory = this.workingMemory.slice(0, 20);
    }
  }

  private isWorkingMemoryRelevant(memory: MemoryEntry): boolean {
    return (
      memory.importance === 'high' ||
      memory.importance === 'critical' ||
      memory.type === 'conversation' ||
      memory.type === 'goal'
    );
  }

  private indexMemory(memory: MemoryEntry): void {
    // Index by tags
    memory.tags.forEach(tag => {
      if (!this.memoryIndex.has(tag)) {
        this.memoryIndex.set(tag, new Set());
      }
      this.memoryIndex.get(tag)!.add(memory.id);
    });

    // Index by content keywords
    const keywords = this.extractKeywords(memory.content);
    keywords.forEach(keyword => {
      if (!this.memoryIndex.has(keyword)) {
        this.memoryIndex.set(keyword, new Set());
      }
      this.memoryIndex.get(keyword)!.add(memory.id);
    });
  }

  private removeFromIndex(memory: MemoryEntry): void {
    memory.tags.forEach(tag => {
      this.memoryIndex.get(tag)?.delete(memory.id);
    });

    const keywords = this.extractKeywords(memory.content);
    keywords.forEach(keyword => {
      this.memoryIndex.get(keyword)?.delete(memory.id);
    });
  }

  private extractKeywords(content: string): string[] {
    const stopWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should']);
    
    return content
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .split(/\s+/)
      .filter(word => word.length > 2 && !stopWords.has(word))
      .slice(0, 10); // Limit keywords
  }

  private matchesQuery(memory: MemoryEntry, query: MemoryQuery): boolean {
    // Type filter
    if (query.type && memory.type !== query.type) {
      return false;
    }

    // Importance filter
    if (query.importance && memory.importance !== query.importance) {
      return false;
    }

    // Tags filter
    if (query.tags && query.tags.length > 0) {
      const hasMatchingTag = query.tags.some(tag => memory.tags.includes(tag));
      if (!hasMatchingTag) {
        return false;
      }
    }

    // Content search
    if (query.content) {
      const searchTerm = query.content.toLowerCase();
      const contentMatch = memory.content.toLowerCase().includes(searchTerm);
      const tagMatch = memory.tags.some(tag => tag.toLowerCase().includes(searchTerm));
      
      if (!contentMatch && !tagMatch) {
        return false;
      }
    }

    // Date range filter
    if (query.dateRange) {
      const memoryTime = memory.timestamp.getTime();
      if (query.dateRange.start && memoryTime < query.dateRange.start.getTime()) {
        return false;
      }
      if (query.dateRange.end && memoryTime > query.dateRange.end.getTime()) {
        return false;
      }
    }

    return true;
  }

  private rankResults(results: MemoryEntry[], query: MemoryQuery): MemoryEntry[] {
    return results
      .map(memory => ({
        memory,
        score: this.calculateRelevanceScore(memory, query)
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, query.limit || 50)
      .map(item => item.memory);
  }

  private calculateRelevanceScore(memory: MemoryEntry, query: MemoryQuery): number {
    let score = 0;

    // Recency score (more recent = higher score)
    const ageInDays = (Date.now() - memory.timestamp.getTime()) / (1000 * 60 * 60 * 24);
    score += Math.max(0, 10 - ageInDays);

    // Access frequency score
    score += memory.accessCount * 2;

    // Importance score
    const importanceScores = { low: 1, medium: 3, high: 5, critical: 10 };
    score += importanceScores[memory.importance];

    // Content relevance score
    if (query.content) {
      const contentLower = memory.content.toLowerCase();
      const queryLower = query.content.toLowerCase();
      
      if (contentLower.includes(queryLower)) {
        score += 10;
      }
      
      // Partial matches
      const queryWords = queryLower.split(' ');
      const matches = queryWords.filter(word => contentLower.includes(word)).length;
      score += (matches / queryWords.length) * 5;
    }

    // Tag relevance score
    if (query.tags) {
      const matchingTags = query.tags.filter(tag => memory.tags.includes(tag)).length;
      score += matchingTags * 3;
    }

    return score;
  }

  private generateId(): string {
    return `mem_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Public API methods
  async forgetMemory(memoryId: string): Promise<boolean> {
    const memory = this.shortTermMemory.get(memoryId) || this.longTermMemory.get(memoryId);
    
    if (memory) {
      this.shortTermMemory.delete(memoryId);
      this.longTermMemory.delete(memoryId);
      this.removeFromIndex(memory);
      
      // Remove from working memory
      this.workingMemory = this.workingMemory.filter(m => m.id !== memoryId);
      
      return true;
    }
    
    return false;
  }

  getMemoryStats(): any {
    return {
      shortTermCount: this.shortTermMemory.size,
      longTermCount: this.longTermMemory.size,
      workingMemoryCount: this.workingMemory.length,
      totalMemories: this.shortTermMemory.size + this.longTermMemory.size,
      indexSize: this.memoryIndex.size
    };
  }

  clearAllMemories(): void {
    this.shortTermMemory.clear();
    this.longTermMemory.clear();
    this.workingMemory = [];
    this.memoryIndex.clear();
    this.setupMemoryCategories();
    console.log('🧠 All memories cleared');
  }
}
