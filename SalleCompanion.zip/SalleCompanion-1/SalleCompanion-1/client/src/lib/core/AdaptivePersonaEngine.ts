export class AdaptivePersonaEngine {
  private traits: Map<string, number> = new Map();
  private context: any = {};
  private evolutionHistory: any[] = [];

  constructor() {
    this.initialize();
  }

  private initialize() {
    // Initialize default traits
    this.traits.set('empathy', 92);
    this.traits.set('logic', 88);
    this.traits.set('creativity', 76);
    this.traits.set('assertiveness', 82);
    this.traits.set('humor', 68);
    this.traits.set('patience', 94);
  }

  evolvePersona(interaction: { trait: string; value: number; context: any }) {
    const currentValue = this.traits.get(interaction.trait) || 50;
    const newValue = Math.min(100, Math.max(0, currentValue + interaction.value));
    
    this.traits.set(interaction.trait, newValue);
    
    this.evolutionHistory.push({
      timestamp: new Date(),
      trait: interaction.trait,
      oldValue: currentValue,
      newValue,
      context: interaction.context
    });

    console.log(`Persona evolved: ${interaction.trait} ${currentValue} -> ${newValue}`);
  }

  getPersonaState() {
    return {
      traits: Object.fromEntries(this.traits),
      mood: this.determineMood(),
      context: this.context,
      history: this.evolutionHistory.slice(-10) // Last 10 changes
    };
  }

  private determineMood(): string {
    const empathy = this.traits.get('empathy') || 50;
    const logic = this.traits.get('logic') || 50;
    const creativity = this.traits.get('creativity') || 50;

    if (empathy > 85 && logic > 80) {
      return 'supportive';
    } else if (logic > 90) {
      return 'analytical';
    } else if (creativity > 80) {
      return 'creative';
    } else if (empathy > 90) {
      return 'nurturing';
    }

    return 'balanced';
  }

  adaptToUser(userProfile: any) {
    // Adapt persona based on user preferences and interaction history
    if (userProfile.preferredCommunicationStyle === 'direct') {
      this.evolvePersona({ trait: 'assertiveness', value: 5, context: 'user_preference' });
    } else if (userProfile.preferredCommunicationStyle === 'gentle') {
      this.evolvePersona({ trait: 'empathy', value: 3, context: 'user_preference' });
    }
  }

  getTrait(name: string): number {
    return this.traits.get(name) || 50;
  }

  setTrait(name: string, value: number) {
    this.traits.set(name, Math.min(100, Math.max(0, value)));
  }
}
