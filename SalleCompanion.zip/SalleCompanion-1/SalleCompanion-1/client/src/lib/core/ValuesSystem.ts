import type { UserValue, ValueAlignment, ValueConflict, ValueEvolution } from "@/types/salle";

export class ValuesSystem {
  private coreValues: Map<string, UserValue> = new Map();
  private valueHierarchy: string[] = [];
  private alignmentHistory: ValueAlignment[] = [];
  private conflictLog: ValueConflict[] = [];

  constructor() {
    this.initialize();
  }

  private initialize() {
    console.log('⚖️ ValuesSystem initializing...');
    this.initializeDefaultValues();
  }

  private initializeDefaultValues() {
    const defaultValues: UserValue[] = [
      {
        name: 'autonomy',
        description: 'Personal freedom and self-determination',
        importance: 0.9,
        confidence: 0.8,
        category: 'personal',
        examples: ['Making my own decisions', 'Having control over my life'],
        lastUpdated: new Date()
      },
      {
        name: 'growth',
        description: 'Continuous learning and self-improvement',
        importance: 0.85,
        confidence: 0.9,
        category: 'personal',
        examples: ['Learning new skills', 'Challenging myself'],
        lastUpdated: new Date()
      },
      {
        name: 'efficiency',
        description: 'Accomplishing goals with minimal waste',
        importance: 0.8,
        confidence: 0.85,
        category: 'professional',
        examples: ['Streamlining processes', 'Time management'],
        lastUpdated: new Date()
      },
      {
        name: 'balance',
        description: 'Maintaining equilibrium between different life aspects',
        importance: 0.75,
        confidence: 0.8,
        category: 'lifestyle',
        examples: ['Work-life balance', 'Mental and physical health'],
        lastUpdated: new Date()
      },
      {
        name: 'authenticity',
        description: 'Being true to oneself and others',
        importance: 0.85,
        confidence: 0.9,
        category: 'personal',
        examples: ['Honest communication', 'Staying true to beliefs'],
        lastUpdated: new Date()
      }
    ];

    defaultValues.forEach(value => {
      this.coreValues.set(value.name, value);
    });

    this.updateValueHierarchy();
  }

  async assessAlignment(action: string, context?: any): Promise<ValueAlignment> {
    try {
      const alignmentScores: Record<string, number> = {};
      let overallAlignment = 0;
      let conflictCount = 0;

      // Assess alignment with each core value
      for (const [valueName, value] of Array.from(this.coreValues)) {
        const score = this.calculateValueAlignment(action, value, context);
        alignmentScores[valueName] = score;
        overallAlignment += score * value.importance;

        if (score < -0.3) {
          conflictCount++;
          this.logValueConflict(valueName, action, score, context);
        }
      }

      const alignment: ValueAlignment = {
        action,
        overallScore: overallAlignment / this.getTotalImportance(),
        valueScores: alignmentScores,
        conflicts: conflictCount,
        recommendations: this.generateAlignmentRecommendations(alignmentScores, action),
        confidence: this.calculateAlignmentConfidence(alignmentScores),
        timestamp: new Date(),
        context
      };

      this.alignmentHistory.push(alignment);
      this.limitHistory();

      return alignment;
    } catch (error) {
      console.error('Value alignment assessment error:', error);
      return this.getDefaultAlignment(action);
    }
  }

  private calculateValueAlignment(action: string, value: UserValue, context?: any): number {
    const actionLower = action.toLowerCase();
    let score = 0;

    // Check for explicit value keywords in action
    const valueKeywords = this.getValueKeywords(value.name);
    const matchingKeywords = valueKeywords.filter(keyword => 
      actionLower.includes(keyword.toLowerCase())
    );

    score += matchingKeywords.length * 0.2;

    // Context-specific alignment scoring
    switch (value.name) {
      case 'autonomy':
        if (actionLower.includes('decide') || actionLower.includes('choose') || actionLower.includes('control')) {
          score += 0.8;
        }
        if (actionLower.includes('force') || actionLower.includes('must') || actionLower.includes('require')) {
          score -= 0.6;
        }
        break;

      case 'growth':
        if (actionLower.includes('learn') || actionLower.includes('improve') || actionLower.includes('develop')) {
          score += 0.8;
        }
        if (actionLower.includes('give up') || actionLower.includes('quit') || actionLower.includes('stagnant')) {
          score -= 0.6;
        }
        break;

      case 'efficiency':
        if (actionLower.includes('optimize') || actionLower.includes('streamline') || actionLower.includes('quick')) {
          score += 0.8;
        }
        if (actionLower.includes('waste') || actionLower.includes('slow') || actionLower.includes('redundant')) {
          score -= 0.6;
        }
        break;

      case 'balance':
        if (actionLower.includes('balance') || actionLower.includes('moderate') || actionLower.includes('equilibrium')) {
          score += 0.8;
        }
        if (actionLower.includes('extreme') || actionLower.includes('all-or-nothing') || actionLower.includes('obsess')) {
          score -= 0.6;
        }
        break;

      case 'authenticity':
        if (actionLower.includes('honest') || actionLower.includes('genuine') || actionLower.includes('true')) {
          score += 0.8;
        }
        if (actionLower.includes('fake') || actionLower.includes('pretend') || actionLower.includes('deceive')) {
          score -= 0.8;
        }
        break;
    }

    // Normalize score to [-1, 1] range
    return Math.max(-1, Math.min(1, score));
  }

  private getValueKeywords(valueName: string): string[] {
    const keywordMap: Record<string, string[]> = {
      autonomy: ['freedom', 'independence', 'self-determination', 'choice', 'control'],
      growth: ['learning', 'development', 'improvement', 'progress', 'evolution'],
      efficiency: ['productivity', 'optimization', 'streamlined', 'effective', 'results'],
      balance: ['harmony', 'equilibrium', 'moderation', 'wellness', 'stability'],
      authenticity: ['genuine', 'honest', 'true', 'real', 'sincere']
    };

    return keywordMap[valueName] || [];
  }

  private generateAlignmentRecommendations(
    valueScores: Record<string, number>, 
    action: string
  ): string[] {
    const recommendations: string[] = [];

    Object.entries(valueScores).forEach(([valueName, score]) => {
      if (score < -0.3) {
        recommendations.push(`Consider how this aligns with your value of ${valueName}`);
      } else if (score > 0.5) {
        recommendations.push(`This action strongly supports your value of ${valueName}`);
      }
    });

    if (recommendations.length === 0) {
      recommendations.push('This action appears neutral regarding your core values');
    }

    return recommendations;
  }

  private calculateAlignmentConfidence(valueScores: Record<string, number>): number {
    const scores = Object.values(valueScores);
    const avgScore = scores.reduce((a, b) => a + Math.abs(b), 0) / scores.length;
    
    // Higher average absolute scores indicate more confident assessment
    return Math.min(1, avgScore + 0.5);
  }

  private logValueConflict(
    valueName: string, 
    action: string, 
    score: number, 
    context?: any
  ) {
    const conflict: ValueConflict = {
      valueName,
      action,
      conflictScore: score,
      timestamp: new Date(),
      context,
      resolution: undefined
    };

    this.conflictLog.push(conflict);
    
    // Keep conflict log manageable
    if (this.conflictLog.length > 100) {
      this.conflictLog = this.conflictLog.slice(-100);
    }

    console.warn(`Value conflict detected: ${valueName} (score: ${score.toFixed(2)})`);
  }

  async evolveValues(feedback: ValueEvolution): Promise<void> {
    const value = this.coreValues.get(feedback.valueName);
    if (!value) {
      console.error(`Value not found: ${feedback.valueName}`);
      return;
    }

    // Update importance based on feedback
    const importanceChange = feedback.reinforcement ? 0.05 : -0.03;
    value.importance = Math.max(0.1, Math.min(1.0, value.importance + importanceChange));

    // Update confidence based on consistency
    const confidenceChange = feedback.consistent ? 0.02 : -0.02;
    value.confidence = Math.max(0.1, Math.min(1.0, value.confidence + confidenceChange));

    // Add new examples if provided
    if (feedback.newExample) {
      value.examples.push(feedback.newExample);
      // Keep examples list manageable
      if (value.examples.length > 10) {
        value.examples = value.examples.slice(-10);
      }
    }

    value.lastUpdated = new Date();
    this.updateValueHierarchy();

    console.log(`Value evolved: ${feedback.valueName} (importance: ${value.importance.toFixed(2)})`);
  }

  private updateValueHierarchy() {
    this.valueHierarchy = Array.from(this.coreValues.entries())
      .sort(([,a], [,b]) => b.importance - a.importance)
      .map(([name]) => name);
  }

  private getTotalImportance(): number {
    return Array.from(this.coreValues.values())
      .reduce((sum, value) => sum + value.importance, 0);
  }

  private limitHistory() {
    if (this.alignmentHistory.length > 200) {
      this.alignmentHistory = this.alignmentHistory.slice(-200);
    }
  }

  private getDefaultAlignment(action: string): ValueAlignment {
    return {
      action,
      overallScore: 0,
      valueScores: {},
      conflicts: 0,
      recommendations: ['Unable to assess value alignment'],
      confidence: 0.3,
      timestamp: new Date()
    };
  }

  // Public API methods
  addValue(value: UserValue): void {
    this.coreValues.set(value.name, value);
    this.updateValueHierarchy();
    console.log(`Added new value: ${value.name}`);
  }

  removeValue(valueName: string): boolean {
    const removed = this.coreValues.delete(valueName);
    if (removed) {
      this.updateValueHierarchy();
      console.log(`Removed value: ${valueName}`);
    }
    return removed;
  }

  getValue(valueName: string): UserValue | undefined {
    return this.coreValues.get(valueName);
  }

  getAllValues(): UserValue[] {
    return Array.from(this.coreValues.values());
  }

  getValueHierarchy(): string[] {
    return [...this.valueHierarchy];
  }

  getAlignmentHistory(limit: number = 50): ValueAlignment[] {
    return this.alignmentHistory.slice(-limit);
  }

  getConflictHistory(limit: number = 50): ValueConflict[] {
    return this.conflictLog.slice(-limit);
  }

  getTopValues(count: number = 5): UserValue[] {
    return this.valueHierarchy
      .slice(0, count)
      .map(name => this.coreValues.get(name)!)
      .filter(Boolean);
  }

  async resolveConflict(conflictId: string, resolution: string): Promise<boolean> {
    const conflict = this.conflictLog.find(c => 
      c.timestamp.getTime().toString() === conflictId
    );

    if (conflict) {
      conflict.resolution = resolution;
      return true;
    }

    return false;
  }

  getValueStats(): any {
    return {
      totalValues: this.coreValues.size,
      averageImportance: Array.from(this.coreValues.values())
        .reduce((sum, v) => sum + v.importance, 0) / this.coreValues.size,
      averageConfidence: Array.from(this.coreValues.values())
        .reduce((sum, v) => sum + v.confidence, 0) / this.coreValues.size,
      totalConflicts: this.conflictLog.length,
      recentAlignments: this.alignmentHistory.length
    };
  }

  clearHistory(): void {
    this.alignmentHistory = [];
    this.conflictLog = [];
    console.log('⚖️ Values history cleared');
  }
}
