import type { AutonomousTask, TaskGoal, TaskExecution, TaskPriority, TaskStatus } from "@/types/salle";

export class TaskSystem {
  private activeTasks: Map<string, AutonomousTask> = new Map();
  private taskQueue: AutonomousTask[] = [];
  private executionHistory: TaskExecution[] = [];
  private currentGoals: Map<string, TaskGoal> = new Map();
  private isProcessing: boolean = false;

  constructor() {
    this.initialize();
  }

  private initialize() {
    console.log('🎯 TaskSystem initializing...');
    this.setupDefaultGoals();
    this.startTaskProcessor();
  }

  private setupDefaultGoals() {
    const defaultGoals: TaskGoal[] = [
      {
        id: this.generateId(),
        name: 'Productivity Enhancement',
        description: 'Help user optimize their workflow and achieve better results',
        priority: 'high',
        metrics: ['tasks_completed', 'time_saved', 'efficiency_score'],
        targetValue: 80,
        currentValue: 0,
        deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
        status: 'active',
        createdAt: new Date(),
        subGoals: []
      },
      {
        id: this.generateId(),
        name: 'Learning Support',
        description: 'Facilitate continuous learning and knowledge acquisition',
        priority: 'medium',
        metrics: ['learning_sessions', 'concepts_mastered', 'knowledge_retention'],
        targetValue: 100,
        currentValue: 0,
        deadline: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000), // 60 days
        status: 'active',
        createdAt: new Date(),
        subGoals: []
      }
    ];

    defaultGoals.forEach(goal => {
      this.currentGoals.set(goal.id, goal);
    });
  }

  async createTask(
    description: string, 
    priority: TaskPriority = 'medium',
    goalId?: string,
    context?: any
  ): Promise<string> {
    const task: AutonomousTask = {
      id: this.generateId(),
      description,
      priority,
      status: 'pending',
      createdAt: new Date(),
      estimatedDuration: this.estimateTaskDuration(description),
      dependencies: [],
      steps: this.generateTaskSteps(description),
      context,
      goalId,
      attempts: 0,
      maxAttempts: 3
    };

    this.activeTasks.set(task.id, task);
    this.taskQueue.push(task);
    this.sortTaskQueue();

    console.log(`Task created: ${task.id} - ${description}`);
    return task.id;
  }

  async executeGoal(goalId: string): Promise<boolean> {
    const goal = this.currentGoals.get(goalId);
    if (!goal) {
      console.error(`Goal not found: ${goalId}`);
      return false;
    }

    try {
      console.log(`Executing goal: ${goal.name}`);
      
      // Create tasks to achieve the goal
      const tasks = await this.generateTasksForGoal(goal);
      
      for (const taskDesc of tasks) {
        await this.createTask(taskDesc, goal.priority, goalId);
      }

      goal.status = 'active';
      goal.startedAt = new Date();

      return true;
    } catch (error) {
      console.error(`Goal execution failed: ${goalId}`, error);
      goal.status = 'failed';
      return false;
    }
  }

  private async generateTasksForGoal(goal: TaskGoal): Promise<string[]> {
    const taskTemplates: Record<string, string[]> = {
      'Productivity Enhancement': [
        'Analyze current workflow patterns',
        'Identify time-wasting activities',
        'Suggest workflow optimizations',
        'Implement task automation suggestions',
        'Monitor productivity metrics'
      ],
      'Learning Support': [
        'Assess current knowledge gaps',
        'Create personalized learning plan',
        'Schedule regular learning sessions',
        'Track learning progress',
        'Provide knowledge reinforcement'
      ]
    };

    return taskTemplates[goal.name] || ['Execute goal-specific actions'];
  }

  private generateTaskSteps(description: string): string[] {
    // Simple step generation based on task description
    const commonSteps = [
      'Analyze requirements',
      'Gather necessary information',
      'Execute primary action',
      'Verify completion',
      'Document results'
    ];

    // Customize steps based on task type
    if (description.toLowerCase().includes('analyze')) {
      return [
        'Collect relevant data',
        'Apply analytical framework',
        'Generate insights',
        'Present findings'
      ];
    } else if (description.toLowerCase().includes('create')) {
      return [
        'Define requirements',
        'Design solution',
        'Implement creation',
        'Review and refine'
      ];
    } else if (description.toLowerCase().includes('optimize')) {
      return [
        'Identify current state',
        'Find improvement opportunities',
        'Implement optimizations',
        'Measure improvements'
      ];
    }

    return commonSteps;
  }

  private estimateTaskDuration(description: string): number {
    // Simple duration estimation in minutes
    const baseTime = 15; // 15 minutes base
    let multiplier = 1;

    if (description.toLowerCase().includes('analyze')) multiplier = 2;
    if (description.toLowerCase().includes('create')) multiplier = 3;
    if (description.toLowerCase().includes('complex')) multiplier = 4;
    if (description.toLowerCase().includes('research')) multiplier = 2.5;

    return baseTime * multiplier;
  }

  private sortTaskQueue() {
    const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
    
    this.taskQueue.sort((a, b) => {
      // Sort by priority first
      const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
      if (priorityDiff !== 0) return priorityDiff;

      // Then by creation date (older first)
      return a.createdAt.getTime() - b.createdAt.getTime();
    });
  }

  private startTaskProcessor() {
    // Process tasks every 5 seconds
    setInterval(() => {
      if (!this.isProcessing && this.taskQueue.length > 0) {
        this.processNextTask();
      }
    }, 5000);
  }

  private async processNextTask() {
    if (this.isProcessing || this.taskQueue.length === 0) return;

    this.isProcessing = true;
    const task = this.taskQueue.shift()!;
    
    try {
      console.log(`Processing task: ${task.description}`);
      
      task.status = 'in_progress';
      task.startedAt = new Date();
      task.attempts++;

      const execution = await this.executeTask(task);
      this.executionHistory.push(execution);

      if (execution.success) {
        task.status = 'completed';
        task.completedAt = new Date();
        task.result = execution.result;
        
        // Update goal progress if applicable
        if (task.goalId) {
          this.updateGoalProgress(task.goalId, execution);
        }
      } else {
        task.status = task.attempts >= task.maxAttempts ? 'failed' : 'pending';
        if (task.status === 'pending') {
          // Re-queue for retry
          this.taskQueue.push(task);
          this.sortTaskQueue();
        }
      }

    } catch (error) {
      console.error(`Task execution error: ${task.id}`, error);
      task.status = 'failed';
      task.error = error instanceof Error ? error.message : String(error);
    }

    this.isProcessing = false;
  }

  private async executeTask(task: AutonomousTask): Promise<TaskExecution> {
    const execution: TaskExecution = {
      taskId: task.id,
      startTime: new Date(),
      endTime: new Date(),
      success: false,
      result: null,
      logs: [],
      stepResults: []
    };

    try {
      execution.logs.push(`Starting task: ${task.description}`);

      // Execute each step
      for (let i = 0; i < task.steps.length; i++) {
        const step = task.steps[i];
        execution.logs.push(`Executing step ${i + 1}: ${step}`);
        
        const stepResult = await this.executeTaskStep(step, task);
        execution.stepResults.push({
          step,
          success: stepResult.success,
          result: stepResult.result,
          duration: stepResult.duration
        });

        if (!stepResult.success) {
          execution.logs.push(`Step failed: ${stepResult.error}`);
          throw new Error(`Step failed: ${step}`);
        }
      }

      execution.success = true;
      execution.result = `Task completed successfully: ${task.description}`;
      execution.logs.push('Task completed successfully');

    } catch (error) {
      execution.success = false;
      execution.result = error instanceof Error ? error.message : String(error);
      execution.logs.push(`Task failed: ${execution.result}`);
    }

    execution.endTime = new Date();
    return execution;
  }

  private async executeTaskStep(step: string, task: AutonomousTask): Promise<{
    success: boolean;
    result: any;
    duration: number;
    error?: string;
  }> {
    const startTime = Date.now();
    
    try {
      // Simulate step execution (in real implementation, this would call appropriate services)
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate processing time

      const result = `Completed: ${step}`;
      
      return {
        success: true,
        result,
        duration: Date.now() - startTime
      };
    } catch (error) {
      return {
        success: false,
        result: null,
        duration: Date.now() - startTime,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  private updateGoalProgress(goalId: string, execution: TaskExecution) {
    const goal = this.currentGoals.get(goalId);
    if (!goal) return;

    // Simple progress calculation
    const completedTasks = this.executionHistory.filter(
      ex => ex.success && this.activeTasks.get(ex.taskId)?.goalId === goalId
    ).length;

    const totalTasks = Array.from(this.activeTasks.values())
      .filter(task => task.goalId === goalId).length;

    if (totalTasks > 0) {
      goal.currentValue = (completedTasks / totalTasks) * goal.targetValue;
      
      if (goal.currentValue >= goal.targetValue) {
        goal.status = 'completed';
        goal.completedAt = new Date();
        console.log(`Goal completed: ${goal.name}`);
      }
    }
  }

  // Public API methods
  getActiveTasks(): AutonomousTask[] {
    return Array.from(this.activeTasks.values());
  }

  getTask(taskId: string): AutonomousTask | undefined {
    return this.activeTasks.get(taskId);
  }

  getTasksByStatus(status: TaskStatus): AutonomousTask[] {
    return Array.from(this.activeTasks.values())
      .filter(task => task.status === status);
  }

  getTasksByGoal(goalId: string): AutonomousTask[] {
    return Array.from(this.activeTasks.values())
      .filter(task => task.goalId === goalId);
  }

  getGoals(): TaskGoal[] {
    return Array.from(this.currentGoals.values());
  }

  getGoal(goalId: string): TaskGoal | undefined {
    return this.currentGoals.get(goalId);
  }

  getExecutionHistory(limit: number = 50): TaskExecution[] {
    return this.executionHistory.slice(-limit);
  }

  async pauseTask(taskId: string): Promise<boolean> {
    const task = this.activeTasks.get(taskId);
    if (task && task.status === 'in_progress') {
      task.status = 'paused';
      task.pausedAt = new Date();
      return true;
    }
    return false;
  }

  async resumeTask(taskId: string): Promise<boolean> {
    const task = this.activeTasks.get(taskId);
    if (task && task.status === 'paused') {
      task.status = 'pending';
      task.pausedAt = undefined;
      this.taskQueue.push(task);
      this.sortTaskQueue();
      return true;
    }
    return false;
  }

  async cancelTask(taskId: string): Promise<boolean> {
    const task = this.activeTasks.get(taskId);
    if (task) {
      task.status = 'cancelled';
      task.cancelledAt = new Date();
      
      // Remove from queue if present
      const queueIndex = this.taskQueue.findIndex(t => t.id === taskId);
      if (queueIndex >= 0) {
        this.taskQueue.splice(queueIndex, 1);
      }
      
      return true;
    }
    return false;
  }

  getTaskStats(): any {
    const tasks = Array.from(this.activeTasks.values());
    const statusCounts = tasks.reduce((acc, task) => {
      acc[task.status] = (acc[task.status] || 0) + 1;
      return acc;
    }, {} as Record<TaskStatus, number>);

    const goals = Array.from(this.currentGoals.values());
    const goalStatusCounts = goals.reduce((acc, goal) => {
      acc[goal.status] = (acc[goal.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalTasks: tasks.length,
      queueLength: this.taskQueue.length,
      statusCounts,
      totalGoals: goals.length,
      goalStatusCounts,
      executionHistoryLength: this.executionHistory.length,
      isProcessing: this.isProcessing
    };
  }

  private generateId(): string {
    return `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  clearCompletedTasks(): number {
    const completedTasks = Array.from(this.activeTasks.entries())
      .filter(([, task]) => task.status === 'completed');
    
    completedTasks.forEach(([taskId]) => {
      this.activeTasks.delete(taskId);
    });

    console.log(`Cleared ${completedTasks.length} completed tasks`);
    return completedTasks.length;
  }

  clearAllTasks(): void {
    this.activeTasks.clear();
    this.taskQueue = [];
    this.executionHistory = [];
    console.log('🎯 All tasks cleared');
  }
}
