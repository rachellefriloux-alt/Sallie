import { useQuery } from "@tanstack/react-query";
import type { PersonaState } from "@shared/schema";

export function usePersona(userId: string) {
  const { data: persona, isLoading } = useQuery<PersonaState>({
    queryKey: ['/api/persona', userId],
    enabled: !!userId,
  });

  return {
    persona,
    loading: isLoading,
  };
}
