import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(true); // For demo purposes
  const [currentUserId, setCurrentUserId] = useState("you");

  const { data: user, isLoading } = useQuery<User>({
    queryKey: ['/api/users', currentUserId],
    enabled: !!currentUserId,
  });

  const login = async (userId: string) => {
    setCurrentUserId(userId);
    setIsAuthenticated(true);
  };

  const logout = () => {
    setCurrentUserId("");
    setIsAuthenticated(false);
  };

  return {
    user,
    loading: isLoading,
    isAuthenticated,
    login,
    logout
  };
}
