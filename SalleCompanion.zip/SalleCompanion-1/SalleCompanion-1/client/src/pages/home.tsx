import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Sidebar } from "@/components/Sidebar";
import { ChatInterface } from "@/components/ChatInterface";
import { PersonaVisualization } from "@/components/PersonaVisualization";
import { TaskPanel } from "@/components/TaskPanel";
import { MemoryDashboard } from "@/components/MemoryDashboard";
import { CreativityDashboard } from "@/components/CreativityDashboard";
import { DeviceControlPanel } from "@/components/DeviceControlPanel";
import { AnalyticsPanel } from "@/components/AnalyticsPanel";
import { FeatureFlagsPanel } from "@/components/FeatureFlagsPanel";
import { ConsentDialog } from "@/components/ConsentDialog";
import { OnboardingTooltip } from "@/components/OnboardingTooltip";
import { EmotionOverlay } from "@/components/EmotionOverlay";
import { VoiceIndicator } from "@/components/VoiceIndicator";

export default function Home() {
  const { user, loading } = useAuth();
  const [activeUser, setActiveUser] = useState("you");
  const [selectedModel, setSelectedModel] = useState("claude");
  const [selectedMode, setSelectedMode] = useState("chat");
  const [showOnboarding, setShowOnboarding] = useState(true);
  const [showConsent, setShowConsent] = useState(false);
  const [systemStatus, setSystemStatus] = useState({ status: "ready", message: "All systems online" });

  // User profiles with permissions
  const userProfiles = {
    you: {
      name: "You",
      avatar: "https://pixabay.com/get/gb5d05698b2a3d1d8af44cd36215543d55b53b18d345d3d712f2e8dfd90881b6bcca03dd0d80a84167e321efcf1ccee8b7a67813a7fcb4824d54890d48da99a74_1280.jpg",
      permissions: {
        fullAccess: true,
        memory: true,
        creativity: true,
        deviceControl: true,
        notifications: true,
        analytics: true
      }
    },
    austin: {
      name: "Austin",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      permissions: {
        fullAccess: false,
        memory: false,
        creativity: true,
        deviceControl: false,
        notifications: false,
        analytics: false
      }
    },
    bella: {
      name: "Bella",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      permissions: {
        fullAccess: false,
        memory: false,
        creativity: true,
        deviceControl: false,
        notifications: false,
        analytics: false
      }
    }
  };

  const currentUserProfile = userProfiles[activeUser as keyof typeof userProfiles];

  if (loading) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 mx-auto mood-gradient rounded-full flex items-center justify-center animate-glow mb-4">
            <i className="fas fa-brain text-white text-xl"></i>
          </div>
          <div className="text-xl text-gray-300">Initializing Salle...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen gradient-bg" data-testid="salle-app">
      <Sidebar
        userProfiles={userProfiles}
        activeUser={activeUser}
        onUserChange={setActiveUser}
        selectedModel={selectedModel}
        onModelChange={setSelectedModel}
        selectedMode={selectedMode}
        onModeChange={setSelectedMode}
        systemStatus={systemStatus}
        data-testid="sidebar"
      />

      <main className="ml-80 min-h-screen p-8" data-testid="main-content">
        {/* Header */}
        <header className="mb-8" data-testid="header">
          <div className="max-w-4xl">
            <p className="text-xl text-gray-300 leading-relaxed">
              Your digital life is a story. I'm here to make sure you're the one holding the pen.
            </p>
            
            <div className="mt-4 flex items-center space-x-4">
              <EmotionOverlay emotion="supportive" message="Supportive & Ready" />
              <VoiceIndicator />
            </div>
          </div>
        </header>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-8" data-testid="feature-grid">
          {/* Chat Interface - spans 2 columns */}
          <div className="lg:col-span-2 xl:col-span-2">
            <ChatInterface 
              activeUser={activeUser}
              selectedModel={selectedModel}
              selectedMode={selectedMode}
              data-testid="chat-interface"
            />
          </div>

          {/* Persona Visualization */}
          <PersonaVisualization 
            userId={activeUser}
            data-testid="persona-visualization"
          />

          {/* Task Panel */}
          <TaskPanel 
            userId={activeUser}
            data-testid="task-panel"
          />

          {/* Memory Dashboard */}
          {currentUserProfile.permissions.memory && (
            <MemoryDashboard 
              userId={activeUser}
              data-testid="memory-dashboard"
            />
          )}

          {/* Creativity Dashboard */}
          {currentUserProfile.permissions.creativity && (
            <CreativityDashboard 
              userId={activeUser}
              data-testid="creativity-dashboard"
            />
          )}

          {/* Insight Card */}
          {currentUserProfile.permissions.fullAccess && (
            <div className="glass-panel rounded-2xl p-6" data-testid="insight-card">
              <h3 className="text-lg font-semibold text-white mb-4">Daily Insight</h3>
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-salle-blue to-salle-teal bg-opacity-20 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <i className="fas fa-star text-salle-gold mt-1"></i>
                    <div>
                      <div className="text-sm font-medium text-gray-200 mb-2">
                        Productivity Pattern Detected
                      </div>
                      <div className="text-xs text-gray-400">
                        You tend to be most creative in the morning. Consider scheduling brainstorming sessions before 11 AM.
                      </div>
                    </div>
                  </div>
                </div>
                
                <button 
                  className="w-full text-center py-2 text-sm text-salle-teal hover:text-salle-blue transition-colors"
                  data-testid="button-more-insights"
                >
                  View More Insights
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Advanced Features */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" data-testid="advanced-features">
          {/* Device Control Panel */}
          {currentUserProfile.permissions.deviceControl && (
            <DeviceControlPanel data-testid="device-control" />
          )}

          {/* Analytics Panel */}
          {currentUserProfile.permissions.analytics && (
            <AnalyticsPanel data-testid="analytics-panel" />
          )}

          {/* Feature Flags Panel */}
          {currentUserProfile.permissions.fullAccess && (
            <FeatureFlagsPanel data-testid="feature-flags" />
          )}
        </div>
      </main>

      {/* Floating Elements */}
      {showConsent && (
        <ConsentDialog 
          onGrant={() => setShowConsent(false)}
          onDecline={() => setShowConsent(false)}
          data-testid="consent-dialog"
        />
      )}

      {showOnboarding && (
        <OnboardingTooltip 
          onDismiss={() => setShowOnboarding(false)}
          data-testid="onboarding-tooltip"
        />
      )}
    </div>
  );
}
