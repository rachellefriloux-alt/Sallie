// Core Salle type definitions

// Emotional Intelligence Types
export interface EmotionalState {
  primary: string;
  secondary?: string;
  intensity: number;
  confidence: number;
  timestamp: Date;
}

export interface EmotionalContext {
  userId: string;
  conversation: any[];
  recentEmotions: EmotionalState[];
  environmentalFactors?: Record<string, any>;
}

export interface EmotionAnalysis {
  userEmotion: EmotionalState;
  responseEmotion: EmotionalState;
  emotionalContent: Record<string, number>;
  empathyLevel: number;
  supportLevel: number;
  confidence: number;
  recommendations: string[];
}

// Memory System Types
export type MemoryType = 'conversation' | 'preference' | 'goal' | 'habit' | 'relationship' | 'work' | 'personal' | 'learning' | 'creative' | 'technical';
export type MemoryImportance = 'low' | 'medium' | 'high' | 'critical';

export interface MemoryEntry {
  id: string;
  content: string;
  type: MemoryType;
  importance: MemoryImportance;
  tags: string[];
  timestamp: Date;
  lastAccessed: Date;
  accessCount: number;
  userId?: string;
  metadata?: Record<string, any>;
}

export interface MemoryQuery {
  content?: string;
  type?: MemoryType;
  importance?: MemoryImportance;
  tags?: string[];
  dateRange?: {
    start?: Date;
    end?: Date;
  };
  limit?: number;
}

// Values System Types
export interface UserValue {
  name: string;
  description: string;
  importance: number; // 0-1 scale
  confidence: number; // 0-1 scale
  category: 'personal' | 'professional' | 'social' | 'spiritual' | 'lifestyle';
  examples: string[];
  lastUpdated: Date;
}

export interface ValueAlignment {
  action: string;
  overallScore: number; // -1 to 1 scale
  valueScores: Record<string, number>;
  conflicts: number;
  recommendations: string[];
  confidence: number;
  timestamp: Date;
  context?: any;
}

export interface ValueConflict {
  valueName: string;
  action: string;
  conflictScore: number;
  timestamp: Date;
  context?: any;
  resolution?: string;
}

export interface ValueEvolution {
  valueName: string;
  reinforcement: boolean;
  consistent: boolean;
  newExample?: string;
  context?: any;
}

// Task System Types
export type TaskStatus = 'pending' | 'in_progress' | 'paused' | 'completed' | 'failed' | 'cancelled';
export type TaskPriority = 'low' | 'medium' | 'high' | 'critical';

export interface AutonomousTask {
  id: string;
  description: string;
  priority: TaskPriority;
  status: TaskStatus;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  pausedAt?: Date;
  cancelledAt?: Date;
  estimatedDuration: number; // in minutes
  actualDuration?: number;
  dependencies: string[];
  steps: string[];
  context?: any;
  goalId?: string;
  attempts: number;
  maxAttempts: number;
  result?: any;
  error?: string;
}

export interface TaskGoal {
  id: string;
  name: string;
  description: string;
  priority: TaskPriority;
  metrics: string[];
  targetValue: number;
  currentValue: number;
  deadline?: Date;
  status: 'active' | 'paused' | 'completed' | 'failed' | 'cancelled';
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  subGoals: string[];
}

export interface TaskExecution {
  taskId: string;
  startTime: Date;
  endTime: Date;
  success: boolean;
  result: any;
  logs: string[];
  stepResults: Array<{
    step: string;
    success: boolean;
    result: any;
    duration: number;
  }>;
}

// Persona Types
export interface PersonaTrait {
  name: string;
  value: number; // 0-100 scale
  confidence: number; // 0-1 scale
  lastUpdated: Date;
}

export interface PersonaState {
  traits: Record<string, number>;
  mood: string;
  context: Record<string, any>;
  history?: Array<{
    timestamp: Date;
    trait: string;
    oldValue: number;
    newValue: number;
    context: any;
  }>;
}

// AI Integration Types
export interface AIModel {
  name: string;
  provider: 'claude' | 'openai' | 'gemini' | 'perplexity' | 'copilot';
  version: string;
  capabilities: string[];
  isAvailable: boolean;
}

export interface AIResponse {
  content: string;
  model: string;
  mode: string;
  emotion?: string;
  persona?: any;
  confidence?: number;
  timestamp: Date;
  metadata?: Record<string, any>;
}

// User and Permission Types
export interface UserPermissions {
  fullAccess: boolean;
  memory: boolean;
  creativity: boolean;
  deviceControl: boolean;
  notifications: boolean;
  analytics: boolean;
}

export interface UserProfile {
  id: string;
  username: string;
  name: string;
  email: string;
  avatar: string;
  permissions: UserPermissions;
  preferences: Record<string, any>;
  createdAt: Date;
  lastActive: Date;
}

// Chat and Communication Types
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  metadata?: {
    model?: string;
    mode?: string;
    emotion?: string;
    confidence?: number;
  };
}

export interface Conversation {
  id: string;
  userId: string;
  title: string;
  messages: ChatMessage[];
  metadata: {
    model?: string;
    mode?: string;
    tags?: string[];
  };
  createdAt: Date;
  updatedAt: Date;
}

// System State Types
export interface SystemStatus {
  status: 'initializing' | 'ready' | 'processing' | 'error' | 'maintenance';
  message: string;
  lastUpdate: Date;
  components: Record<string, boolean>;
}

export interface FeatureFlag {
  name: string;
  enabled: boolean;
  description: string;
  userLevel?: 'all' | 'owner' | 'admin';
}

// Analytics and Insights Types
export interface UserActivity {
  date: Date;
  interactions: number;
  conversationTime: number;
  tasksCompleted: number;
  featuresUsed: string[];
}

export interface Insight {
  id: string;
  type: 'productivity' | 'pattern' | 'recommendation' | 'achievement';
  title: string;
  description: string;
  confidence: number;
  data: any;
  createdAt: Date;
  acknowledged?: boolean;
}

// Device and IoT Types
export interface Device {
  id: string;
  name: string;
  type: 'light' | 'thermostat' | 'camera' | 'speaker' | 'sensor';
  status: 'online' | 'offline' | 'error';
  properties: Record<string, any>;
  lastUpdate: Date;
}

export interface DeviceCommand {
  deviceId: string;
  action: string;
  parameters: Record<string, any>;
  timestamp: Date;
  success?: boolean;
  error?: string;
}

// Voice and Audio Types
export interface VoiceSession {
  id: string;
  startTime: Date;
  endTime?: Date;
  transcript: string;
  confidence: number;
  language: string;
  processed: boolean;
}

export interface VoiceCommand {
  intent: string;
  parameters: Record<string, any>;
  confidence: number;
  rawText: string;
}

// Export utility types
export type SalleEvent = {
  type: string;
  payload: any;
  timestamp: Date;
  source: string;
};

export type SalleError = {
  code: string;
  message: string;
  details?: any;
  timestamp: Date;
  recoverable: boolean;
};
