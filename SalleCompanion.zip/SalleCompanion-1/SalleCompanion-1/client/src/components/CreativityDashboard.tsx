import { Button } from "@/components/ui/button";

interface CreativityDashboardProps {
  userId: string;
}

export function CreativityDashboard({ userId }: CreativityDashboardProps) {
  const creativeTools = [
    {
      id: "brainstorming",
      name: "Brainstorming",
      description: "Generate ideas and solutions",
      icon: "fas fa-lightbulb",
      color: "text-salle-gold"
    },
    {
      id: "writing",
      name: "Writing Assistant",
      description: "Craft compelling content",
      icon: "fas fa-pen-fancy",
      color: "text-salle-teal"
    },
    {
      id: "strategy",
      name: "Strategy Mode",
      description: "Plan and analyze decisions",
      icon: "fas fa-chess",
      color: "text-salle-blue"
    }
  ];

  const handleToolClick = (toolId: string) => {
    console.log(`Opening ${toolId} tool for user ${userId}`);
    // Implementation would open the specific creative tool
  };

  return (
    <div className="glass-panel rounded-2xl p-6" data-testid="creativity-dashboard">
      <h3 className="text-lg font-semibold text-white mb-4">Creative Space</h3>
      
      <div className="space-y-3">
        {creativeTools.map((tool) => (
          <Button
            key={tool.id}
            variant="ghost"
            className="w-full text-left p-3 bg-gray-800 bg-opacity-50 rounded-lg hover:bg-opacity-70 transition-colors justify-start"
            onClick={() => handleToolClick(tool.id)}
            data-testid={`button-${tool.id}`}
          >
            <div className="flex items-center">
              <i className={`${tool.icon} ${tool.color} mr-3`}></i>
              <div>
                <div className="text-sm font-medium text-gray-200">{tool.name}</div>
                <div className="text-xs text-gray-400">{tool.description}</div>
              </div>
            </div>
          </Button>
        ))}
      </div>
    </div>
  );
}
