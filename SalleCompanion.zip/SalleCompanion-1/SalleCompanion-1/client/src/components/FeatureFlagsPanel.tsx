import { useState } from "react";
import { Button } from "@/components/ui/button";

export function FeatureFlagsPanel() {
  const [flags, setFlags] = useState({
    voiceRecognition: true,
    autoLearning: true,
    privacyMode: false,
    advancedAnalytics: true,
    experimentalFeatures: false
  });

  const toggleFlag = (flagName: keyof typeof flags) => {
    setFlags(prev => ({
      ...prev,
      [flagName]: !prev[flagName]
    }));
  };

  const flagConfig = [
    { key: 'voiceRecognition', label: 'Voice Recognition', color: 'salle-blue' },
    { key: 'autoLearning', label: 'Auto-learning', color: 'salle-teal' },
    { key: 'privacyMode', label: 'Privacy Mode', color: 'gray-600' },
    { key: 'advancedAnalytics', label: 'Advanced Analytics', color: 'salle-gold' },
    { key: 'experimentalFeatures', label: 'Experimental Features', color: 'salle-coral' },
  ];

  return (
    <div className="glass-panel rounded-2xl p-6" data-testid="feature-flags">
      <h3 className="text-lg font-semibold text-white mb-4">System Settings</h3>
      
      <div className="space-y-3">
        {flagConfig.map((config) => {
          const isEnabled = flags[config.key as keyof typeof flags];
          return (
            <div key={config.key} className="flex items-center justify-between">
              <span className="text-sm text-gray-200">{config.label}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleFlag(config.key as keyof typeof flags)}
                className={`w-12 h-6 rounded-full relative transition-colors ${
                  isEnabled ? `bg-${config.color}` : 'bg-gray-600'
                }`}
                data-testid={`toggle-${config.key}`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${
                  isEnabled ? 'right-0.5' : 'left-0.5'
                }`}></div>
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
