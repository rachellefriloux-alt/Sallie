interface EmotionOverlayProps {
  emotion: string;
  message: string;
}

export function EmotionOverlay({ emotion, message }: EmotionOverlayProps) {
  const getEmotionIcon = (emotion: string) => {
    switch (emotion) {
      case "supportive": return "fas fa-heart";
      case "creative": return "fas fa-lightbulb";
      case "analytical": return "fas fa-brain";
      case "playful": return "fas fa-smile";
      default: return "fas fa-heart";
    }
  };

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case "supportive": return "text-salle-coral";
      case "creative": return "text-salle-gold";
      case "analytical": return "text-salle-blue";
      case "playful": return "text-salle-teal";
      default: return "text-salle-coral";
    }
  };

  return (
    <div className="emotion-overlay px-4 py-2 rounded-full glass-panel" data-testid="emotion-overlay">
      <i className={`${getEmotionIcon(emotion)} ${getEmotionColor(emotion)} mr-2`}></i>
      <span className="text-sm text-gray-200">{message}</span>
    </div>
  );
}
