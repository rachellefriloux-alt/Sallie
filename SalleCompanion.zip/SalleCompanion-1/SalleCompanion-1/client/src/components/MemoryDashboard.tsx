import { useQuery } from "@tanstack/react-query";
import type { Memory } from "@shared/schema";

interface MemoryDashboardProps {
  userId: string;
}

export function MemoryDashboard({ userId }: MemoryDashboardProps) {
  const { data: memories = [], isLoading } = useQuery<Memory[]>({
    queryKey: ['/api/memories/user', userId],
  });

  if (isLoading) {
    return (
      <div className="glass-panel rounded-2xl p-6" data-testid="memory-loading">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-700 rounded w-3/4 mb-4"></div>
          <div className="space-y-4">
            <div className="h-16 bg-gray-700 rounded"></div>
            <div className="h-16 bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  const recentMemories = memories.slice(0, 3);
  const coreValues = ["Efficiency", "Growth", "Balance", "Innovation"];

  return (
    <div className="glass-panel rounded-2xl p-6" data-testid="memory-dashboard">
      <h3 className="text-lg font-semibold text-white mb-4">Memory & Context</h3>
      
      <div className="space-y-4">
        <div className="bg-gray-800 bg-opacity-50 rounded-lg p-3" data-testid="recent-memories">
          <div className="text-sm font-medium text-gray-200 mb-1">Recent Memories</div>
          <div className="text-xs text-gray-400">
            {recentMemories.length > 0 
              ? recentMemories.map(m => m.content).join(', ')
              : "Building memories as we interact..."
            }
          </div>
        </div>
        
        <div className="bg-gray-800 bg-opacity-50 rounded-lg p-3" data-testid="core-values">
          <div className="text-sm font-medium text-gray-200 mb-1">Core Values</div>
          <div className="flex flex-wrap gap-2 mt-2">
            {coreValues.map((value, index) => (
              <span 
                key={value}
                className={`px-2 py-1 text-xs rounded-full ${
                  index === 0 ? 'bg-salle-blue bg-opacity-30 text-salle-blue' :
                  index === 1 ? 'bg-salle-teal bg-opacity-30 text-salle-teal' :
                  index === 2 ? 'bg-salle-coral bg-opacity-30 text-salle-coral' :
                  'bg-salle-gold bg-opacity-30 text-salle-gold'
                }`}
                data-testid={`value-${value.toLowerCase()}`}
              >
                {value}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
