import { useState, useRef, useEffect } from "react";
import { useChat } from "@/hooks/useChat";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface ChatInterfaceProps {
  activeUser: string;
  selectedModel: string;
  selectedMode: string;
}

export function ChatInterface({ activeUser, selectedModel, selectedMode }: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const { messages, sendMessage, isLoading } = useChat(activeUser);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!message.trim()) return;
    
    await sendMessage({ message, model: selectedModel, mode: selectedMode });
    setMessage("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const toggleVoice = () => {
    setIsVoiceActive(!isVoiceActive);
  };

  return (
    <div className="glass-panel rounded-2xl p-6" data-testid="chat-interface">
      <div className="flex items-center justify-between mb-6" data-testid="chat-header">
        <h2 className="text-xl font-semibold text-white">Conversation</h2>
        <div className="flex items-center space-x-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={toggleVoice}
            className={`p-2 hover:bg-white hover:bg-opacity-10 ${
              isVoiceActive ? 'text-salle-teal' : 'text-gray-400'
            }`}
            data-testid="button-voice"
          >
            <i className="fas fa-microphone"></i>
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-2 hover:bg-white hover:bg-opacity-10 text-gray-400"
            data-testid="button-clear"
          >
            <i className="fas fa-eraser"></i>
          </Button>
        </div>
      </div>
      
      {/* Messages */}
      <div className="h-96 overflow-y-auto mb-4 space-y-4" data-testid="chat-messages">
        {messages.length === 0 ? (
          <div className="text-center text-gray-400 py-8">
            Start a conversation with Salle...
          </div>
        ) : (
          messages.map((msg, index) => (
            <div 
              key={index} 
              className="chat-message flex items-start space-x-3"
              data-testid={`message-${index}`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                msg.role === 'user' ? 'bg-salle-blue' : 'mood-gradient'
              }`}>
                <i className={`${msg.role === 'user' ? 'fas fa-user' : 'fas fa-brain'} text-white text-sm`}></i>
              </div>
              <div className={`flex-1 rounded-lg p-3 ${
                msg.role === 'user' ? 'bg-gray-800' : 'bg-salle-blue bg-opacity-20'
              }`}>
                <p className="text-gray-200">{msg.content}</p>
                <div className="text-xs text-gray-400 mt-1">{msg.timestamp}</div>
              </div>
            </div>
          ))
        )}
        {isLoading && (
          <div className="chat-message flex items-start space-x-3" data-testid="loading-message">
            <div className="w-8 h-8 rounded-full mood-gradient flex items-center justify-center">
              <i className="fas fa-brain text-white text-sm"></i>
            </div>
            <div className="flex-1 bg-salle-blue bg-opacity-20 rounded-lg p-3">
              <div className="text-gray-200">Thinking...</div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Message Input */}
      <div className="flex items-center space-x-3" data-testid="message-input">
        <div className="flex-1 relative">
          <Input
            type="text"
            placeholder="Type your message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="w-full bg-gray-800 border-gray-600 rounded-lg px-4 py-3 pr-12 text-white placeholder-gray-400 focus:ring-2 focus:ring-salle-blue focus:border-transparent"
            data-testid="input-message"
          />
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleVoice}
            className={`absolute right-3 top-1/2 transform -translate-y-1/2 ${
              isVoiceActive ? 'text-salle-teal' : 'text-gray-400'
            } hover:text-salle-teal transition-colors`}
            data-testid="button-voice-input"
          >
            <i className="fas fa-microphone"></i>
          </Button>
        </div>
        <Button
          onClick={handleSendMessage}
          disabled={!message.trim() || isLoading}
          className="bg-salle-blue hover:bg-blue-600 text-white px-6 py-3 rounded-lg transition-colors"
          data-testid="button-send"
        >
          <i className="fas fa-paper-plane"></i>
        </Button>
      </div>
    </div>
  );
}
