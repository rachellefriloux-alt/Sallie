import { Button } from "@/components/ui/button";

interface ConsentDialogProps {
  onGrant: () => void;
  onDecline: () => void;
}

export function ConsentDialog({ onGrant, onDecline }: ConsentDialogProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" data-testid="consent-dialog">
      <div className="glass-panel rounded-2xl p-8 max-w-md mx-4">
        <h3 className="text-xl font-semibold text-white mb-4">Permission Request</h3>
        <p className="text-gray-300 mb-6">
          Salle would like to access your calendar to provide better scheduling assistance. 
          This data stays on your device and is never shared.
        </p>
        <div className="flex space-x-4">
          <Button 
            onClick={onGrant}
            className="flex-1 bg-salle-blue hover:bg-blue-600 text-white py-2 px-4 rounded-lg transition-colors"
            data-testid="button-grant"
          >
            Grant Permission
          </Button>
          <Button 
            variant="secondary"
            onClick={onDecline}
            className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded-lg transition-colors"
            data-testid="button-decline"
          >
            Not Now
          </Button>
        </div>
      </div>
    </div>
  );
}
