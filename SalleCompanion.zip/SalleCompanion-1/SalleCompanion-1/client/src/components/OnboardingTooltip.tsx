import { Button } from "@/components/ui/button";

interface OnboardingTooltipProps {
  onDismiss: () => void;
}

export function OnboardingTooltip({ onDismiss }: OnboardingTooltipProps) {
  return (
    <div className="fixed top-20 right-8 glass-panel rounded-2xl p-6 max-w-sm z-40" data-testid="onboarding-tooltip">
      <div className="flex items-start space-x-3">
        <div className="w-8 h-8 bg-salle-teal rounded-full flex items-center justify-center">
          <i className="fas fa-info text-white text-sm"></i>
        </div>
        <div className="flex-1">
          <h4 className="font-semibold text-white mb-2">Welcome to Salle!</h4>
          <p className="text-sm text-gray-300 mb-4">
            I'm your AI companion, ready to help with everything from task management to creative brainstorming. 
            Try asking me something!
          </p>
          <Button
            onClick={onDismiss}
            className="bg-salle-blue hover:bg-blue-600 text-white text-sm py-2 px-4 rounded-lg transition-colors"
            data-testid="button-dismiss"
          >
            Got it!
          </Button>
        </div>
      </div>
    </div>
  );
}
