export function VoiceIndicator() {
  const waves = [
    { height: 'h-6', delay: '0s' },
    { height: 'h-4', delay: '0.1s' },
    { height: 'h-8', delay: '0.2s' },
    { height: 'h-5', delay: '0.3s' },
    { height: 'h-7', delay: '0.4s' },
  ];

  return (
    <div className="flex items-center space-x-1" data-testid="voice-indicator">
      {waves.map((wave, index) => (
        <div
          key={index}
          className={`voice-wave w-1 ${wave.height} bg-salle-teal rounded`}
          style={{ animationDelay: wave.delay }}
        ></div>
      ))}
    </div>
  );
}
