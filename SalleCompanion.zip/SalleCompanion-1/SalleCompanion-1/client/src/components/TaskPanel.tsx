import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import type { Task } from "@shared/schema";

interface TaskPanelProps {
  userId: string;
}

export function TaskPanel({ userId }: TaskPanelProps) {
  const [showAddTask, setShowAddTask] = useState(false);
  const [newTask, setNewTask] = useState("");
  const queryClient = useQueryClient();

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks/user', userId],
  });

  const addTaskMutation = useMutation({
    mutationFn: async (taskData: { title: string; userId: string }) => {
      const response = await apiRequest('POST', '/api/tasks', taskData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/user', userId] });
      setNewTask("");
      setShowAddTask(false);
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Task> }) => {
      const response = await apiRequest('PATCH', `/api/tasks/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/user', userId] });
    },
  });

  const handleAddTask = () => {
    if (!newTask.trim()) return;
    addTaskMutation.mutate({
      title: newTask,
      userId: userId
    });
  };

  const toggleTaskStatus = (task: Task) => {
    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    updateTaskMutation.mutate({
      id: task.id,
      updates: { status: newStatus }
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-salle-coral';
      case 'medium': return 'bg-salle-teal';
      case 'low': return 'bg-salle-gold';
      default: return 'bg-gray-400';
    }
  };

  const formatDueDate = (dueDate: Date | null) => {
    if (!dueDate) return 'No due date';
    const now = new Date();
    const due = new Date(dueDate);
    const diffHours = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60));
    
    if (diffHours < 0) return 'Overdue';
    if (diffHours < 24) return `Due in ${diffHours} hours`;
    if (diffHours < 48) return 'Due tomorrow';
    return 'This week';
  };

  if (isLoading) {
    return (
      <div className="glass-panel rounded-2xl p-6" data-testid="task-loading">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-700 rounded w-3/4 mb-4"></div>
          <div className="space-y-3">
            <div className="h-12 bg-gray-700 rounded"></div>
            <div className="h-12 bg-gray-700 rounded"></div>
            <div className="h-12 bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-panel rounded-2xl p-6" data-testid="task-panel">
      <div className="flex items-center justify-between mb-4" data-testid="task-header">
        <h3 className="text-lg font-semibold text-white">Active Tasks</h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowAddTask(!showAddTask)}
          className="p-2 hover:bg-white hover:bg-opacity-10 text-salle-teal"
          data-testid="button-add-task"
        >
          <i className="fas fa-plus"></i>
        </Button>
      </div>

      {showAddTask && (
        <div className="mb-4 space-y-2" data-testid="add-task-form">
          <Input
            placeholder="Enter task title..."
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddTask()}
            className="bg-gray-800 border-gray-600 text-white"
            data-testid="input-new-task"
          />
          <div className="flex space-x-2">
            <Button
              size="sm"
              onClick={handleAddTask}
              disabled={!newTask.trim() || addTaskMutation.isPending}
              className="bg-salle-blue hover:bg-blue-600"
              data-testid="button-save-task"
            >
              Add Task
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAddTask(false)}
              className="text-gray-400 hover:text-white"
              data-testid="button-cancel-task"
            >
              Cancel
            </Button>
          </div>
        </div>
      )}
      
      <div className="space-y-3" data-testid="task-list">
        {tasks.length === 0 ? (
          <div className="text-center text-gray-400 py-8">
            No tasks yet. Click + to add one!
          </div>
        ) : (
          tasks.map((task) => (
            <div 
              key={task.id}
              className="flex items-center space-x-3 p-3 bg-gray-800 bg-opacity-50 rounded-lg"
              data-testid={`task-${task.id}`}
            >
              <button
                onClick={() => toggleTaskStatus(task)}
                className={`w-4 h-4 rounded border-2 flex items-center justify-center ${
                  task.status === 'completed' 
                    ? 'bg-salle-blue border-salle-blue' 
                    : 'border-salle-blue hover:bg-salle-blue hover:bg-opacity-20'
                }`}
                data-testid={`button-toggle-${task.id}`}
              >
                {task.status === 'completed' && (
                  <i className="fas fa-check text-white text-xs"></i>
                )}
              </button>
              <div className="flex-1">
                <div className={`text-sm ${
                  task.status === 'completed' 
                    ? 'text-gray-400 line-through' 
                    : 'text-gray-200'
                }`}>
                  {task.title}
                </div>
                <div className="text-xs text-gray-500">
                  {formatDueDate(task.dueDate)}
                </div>
              </div>
              <div className={`w-2 h-2 rounded-full ${getPriorityColor(task.priority)}`}></div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
