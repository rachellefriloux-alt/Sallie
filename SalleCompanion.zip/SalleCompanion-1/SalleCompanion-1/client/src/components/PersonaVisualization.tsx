import { usePersona } from "@/hooks/usePersona";

interface PersonaVisualizationProps {
  userId: string;
}

export function PersonaVisualization({ userId }: PersonaVisualizationProps) {
  const { persona, loading } = usePersona(userId);

  if (loading) {
    return (
      <div className="glass-panel rounded-2xl p-6" data-testid="persona-loading">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-700 rounded w-3/4 mb-4"></div>
          <div className="w-24 h-24 mx-auto bg-gray-700 rounded-full mb-4"></div>
          <div className="space-y-2">
            <div className="h-3 bg-gray-700 rounded"></div>
            <div className="h-3 bg-gray-700 rounded w-5/6"></div>
          </div>
        </div>
      </div>
    );
  }

  const traits = (persona?.traits as { empathy: number; logic: number; creativity: number }) || { empathy: 92, logic: 88, creativity: 76 };
  const mood = persona?.mood || "supportive";

  const getMoodText = (mood: string) => {
    switch (mood) {
      case "supportive": return "Supportive & Strategic";
      case "creative": return "Creative & Inspired";
      case "analytical": return "Analytical & Precise";
      default: return "Supportive & Ready";
    }
  };

  return (
    <div className="glass-panel rounded-2xl p-6" data-testid="persona-visualization">
      <h3 className="text-lg font-semibold text-white mb-4">Persona State</h3>
      
      {/* Animated Avatar */}
      <div className="text-center mb-6" data-testid="animated-avatar">
        <div className="w-24 h-24 mx-auto mood-gradient rounded-full flex items-center justify-center animate-float mb-4">
          <i className="fas fa-brain text-white text-3xl"></i>
        </div>
        <div className="space-y-2">
          <div className="text-sm text-gray-400">Current Mood</div>
          <div className="text-salle-teal font-medium" data-testid="text-mood">
            {getMoodText(mood)}
          </div>
        </div>
      </div>
      
      {/* Persona Traits */}
      <div className="space-y-3" data-testid="persona-traits">
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-400">Empathy</span>
          <div className="flex-1 mx-3 bg-gray-700 rounded-full h-2">
            <div 
              className="bg-salle-coral h-2 rounded-full transition-all duration-1000"
              style={{ width: `${traits.empathy}%` }}
              data-testid="bar-empathy"
            ></div>
          </div>
          <span className="text-sm text-gray-300" data-testid="text-empathy">{traits.empathy}%</span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-400">Logic</span>
          <div className="flex-1 mx-3 bg-gray-700 rounded-full h-2">
            <div 
              className="bg-salle-blue h-2 rounded-full transition-all duration-1000"
              style={{ width: `${traits.logic}%` }}
              data-testid="bar-logic"
            ></div>
          </div>
          <span className="text-sm text-gray-300" data-testid="text-logic">{traits.logic}%</span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-400">Creativity</span>
          <div className="flex-1 mx-3 bg-gray-700 rounded-full h-2">
            <div 
              className="bg-salle-gold h-2 rounded-full transition-all duration-1000"
              style={{ width: `${traits.creativity}%` }}
              data-testid="bar-creativity"
            ></div>
          </div>
          <span className="text-sm text-gray-300" data-testid="text-creativity">{traits.creativity}%</span>
        </div>
      </div>
    </div>
  );
}
