export function AnalyticsPanel() {
  const analytics = {
    conversations: 127,
    dailyAverage: "4.2h",
    tasksCompleted: 23,
    weeklyGoals: 89
  };

  return (
    <div className="glass-panel rounded-2xl p-6" data-testid="analytics-panel">
      <h3 className="text-lg font-semibold text-white mb-4">Analytics</h3>
      
      <div className="space-y-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-salle-blue" data-testid="stat-conversations">
            {analytics.conversations}
          </div>
          <div className="text-xs text-gray-400">Conversations this week</div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-center">
          <div>
            <div className="text-lg font-semibold text-salle-teal" data-testid="stat-daily-avg">
              {analytics.dailyAverage}
            </div>
            <div className="text-xs text-gray-400">Daily average</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-salle-gold" data-testid="stat-tasks">
              {analytics.tasksCompleted}
            </div>
            <div className="text-xs text-gray-400">Tasks completed</div>
          </div>
        </div>
        
        <div className="text-center pt-2 border-t border-gray-700">
          <div className="text-lg font-semibold text-salle-coral" data-testid="stat-goals">
            {analytics.weeklyGoals}%
          </div>
          <div className="text-xs text-gray-400">Weekly goals progress</div>
        </div>
      </div>
    </div>
  );
}
