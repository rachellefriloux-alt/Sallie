import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface UserProfile {
  name: string;
  avatar: string;
  permissions: {
    fullAccess: boolean;
    memory: boolean;
    creativity: boolean;
    deviceControl: boolean;
    notifications: boolean;
    analytics: boolean;
  };
}

interface SidebarProps {
  userProfiles: Record<string, UserProfile>;
  activeUser: string;
  onUserChange: (user: string) => void;
  selectedModel: string;
  onModelChange: (model: string) => void;
  selectedMode: string;
  onModeChange: (mode: string) => void;
  systemStatus: { status: string; message: string };
}

export function Sidebar({
  userProfiles,
  activeUser,
  onUserChange,
  selectedModel,
  onModelChange,
  selectedMode,
  onModeChange,
  systemStatus,
}: SidebarProps) {
  return (
    <aside className="fixed left-0 top-0 w-80 h-full glass-panel z-20 p-6" data-testid="sidebar">
      {/* Logo */}
      <div className="flex items-center mb-8" data-testid="logo">
        <div className="w-12 h-12 rounded-full mood-gradient flex items-center justify-center animate-glow mr-3">
          <i className="fas fa-brain text-white text-xl"></i>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Salle</h1>
          <p className="text-salle-teal text-sm">Your AI Companion</p>
        </div>
      </div>

      {/* User Profiles */}
      <div className="mb-8" data-testid="user-profiles">
        <h3 className="text-sm font-semibold text-gray-400 mb-4 uppercase tracking-wider">Users</h3>
        <div className="space-y-3">
          {Object.entries(userProfiles).map(([key, profile]) => (
            <div 
              key={key}
              className={`user-entry flex items-center p-3 rounded-lg cursor-pointer transition-all hover:bg-white hover:bg-opacity-10 ${
                activeUser === key ? 'bg-salle-blue bg-opacity-20' : ''
              }`}
              onClick={() => onUserChange(key)}
              data-testid={`user-${key}`}
            >
              <img 
                src={profile.avatar} 
                alt={profile.name} 
                className="w-10 h-10 rounded-full mr-3 border-2 border-salle-blue"
              />
              <div className="flex-1">
                <div className="font-medium text-white">{profile.name}</div>
                <div className="text-xs text-gray-400">
                  {profile.permissions.fullAccess ? 'Owner' : 'Guest'}
                </div>
              </div>
              <span className={`px-2 py-1 text-white text-xs rounded-full ${
                profile.permissions.fullAccess ? 'bg-salle-blue' : 'bg-gray-600'
              }`}>
                {profile.permissions.fullAccess ? 'Owner' : 'Guest'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* AI Configuration */}
      <div className="mb-8" data-testid="ai-config">
        <h3 className="text-sm font-semibold text-gray-400 mb-4 uppercase tracking-wider">AI Configuration</h3>
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Model</label>
            <Select value={selectedModel} onValueChange={onModelChange}>
              <SelectTrigger className="w-full bg-gray-800 border-gray-600 text-white" data-testid="select-model">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="claude">Claude 3.7</SelectItem>
                <SelectItem value="perplexity">Perplexity</SelectItem>
                <SelectItem value="gemini">Gemini</SelectItem>
                <SelectItem value="gpt5">GPT-5</SelectItem>
                <SelectItem value="copilot">Copilot</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Mode</label>
            <Select value={selectedMode} onValueChange={onModeChange}>
              <SelectTrigger className="w-full bg-gray-800 border-gray-600 text-white" data-testid="select-mode">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="chat">Chat</SelectItem>
                <SelectItem value="agent">Agent</SelectItem>
                <SelectItem value="advisory">Advisory</SelectItem>
                <SelectItem value="creative">Creative</SelectItem>
                <SelectItem value="sisr">SISR</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="flex items-center justify-between p-3 bg-gray-800 bg-opacity-50 rounded-lg" data-testid="system-status">
        <div className="flex items-center">
          <div className={`status-dot ${systemStatus.status} mr-2`}></div>
          <span className="text-sm text-gray-300">{systemStatus.message}</span>
        </div>
        <div className="text-xs text-gray-500">Just now</div>
      </div>
    </aside>
  );
}
