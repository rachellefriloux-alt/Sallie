import { useState } from "react";
import { Button } from "@/components/ui/button";

export function DeviceControlPanel() {
  const [lightsOn, setLightsOn] = useState(true);
  const [temperature, setTemperature] = useState(72);

  const toggleLights = () => {
    setLightsOn(!lightsOn);
  };

  return (
    <div className="glass-panel rounded-2xl p-6" data-testid="device-control">
      <h3 className="text-lg font-semibold text-white mb-4">Device Control</h3>
      
      <div className="space-y-3">
        <div className="flex items-center justify-between p-3 bg-gray-800 bg-opacity-50 rounded-lg">
          <div className="flex items-center">
            <i className="fas fa-lightbulb text-salle-gold mr-3"></i>
            <span className="text-sm text-gray-200">Smart Lights</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleLights}
            className={`w-12 h-6 rounded-full relative transition-colors ${
              lightsOn ? 'bg-salle-blue' : 'bg-gray-600'
            }`}
            data-testid="toggle-lights"
          >
            <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${
              lightsOn ? 'right-0.5' : 'left-0.5'
            }`}></div>
          </Button>
        </div>
        
        <div className="flex items-center justify-between p-3 bg-gray-800 bg-opacity-50 rounded-lg">
          <div className="flex items-center">
            <i className="fas fa-thermometer-half text-salle-coral mr-3"></i>
            <span className="text-sm text-gray-200">Temperature</span>
          </div>
          <span className="text-sm text-gray-300" data-testid="temperature">{temperature}°F</span>
        </div>
      </div>
    </div>
  );
}
