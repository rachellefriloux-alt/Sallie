import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertConversationSchema, insertTaskSchema, insertMemorySchema, insertPersonaStateSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'chat_message') {
          // Broadcast to all connected clients
          wss.clients.forEach(client => {
            if (client.readyState === ws.OPEN) {
              client.send(JSON.stringify({
                type: 'chat_message',
                data: data.payload
              }));
            }
          });
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // User routes
  app.get('/api/users/:id', async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get user' });
    }
  });

  app.get('/api/users/firebase/:uid', async (req, res) => {
    try {
      const user = await storage.getUserByFirebaseUid(req.params.uid);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get user' });
    }
  });

  app.post('/api/users', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: 'Invalid user data', error });
    }
  });

  app.patch('/api/users/:id', async (req, res) => {
    try {
      const updates = req.body;
      const user = await storage.updateUser(req.params.id, updates);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user' });
    }
  });

  // Conversation routes
  app.get('/api/conversations/user/:userId', async (req, res) => {
    try {
      const conversations = await storage.getConversationsByUserId(req.params.userId);
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get conversations' });
    }
  });

  app.post('/api/conversations', async (req, res) => {
    try {
      const conversationData = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation(conversationData);
      res.json(conversation);
    } catch (error) {
      res.status(400).json({ message: 'Invalid conversation data', error });
    }
  });

  app.patch('/api/conversations/:id', async (req, res) => {
    try {
      const updates = req.body;
      const conversation = await storage.updateConversation(req.params.id, updates);
      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }
      res.json(conversation);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update conversation' });
    }
  });

  // Task routes
  app.get('/api/tasks/user/:userId', async (req, res) => {
    try {
      const tasks = await storage.getTasksByUserId(req.params.userId);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get tasks' });
    }
  });

  app.post('/api/tasks', async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.json(task);
    } catch (error) {
      res.status(400).json({ message: 'Invalid task data', error });
    }
  });

  app.patch('/api/tasks/:id', async (req, res) => {
    try {
      const updates = req.body;
      const task = await storage.updateTask(req.params.id, updates);
      if (!task) {
        return res.status(404).json({ message: 'Task not found' });
      }
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update task' });
    }
  });

  app.delete('/api/tasks/:id', async (req, res) => {
    try {
      const deleted = await storage.deleteTask(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: 'Task not found' });
      }
      res.json({ message: 'Task deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete task' });
    }
  });

  // Memory routes
  app.get('/api/memories/user/:userId', async (req, res) => {
    try {
      const memories = await storage.getMemoriesByUserId(req.params.userId);
      res.json(memories);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get memories' });
    }
  });

  app.post('/api/memories', async (req, res) => {
    try {
      const memoryData = insertMemorySchema.parse(req.body);
      const memory = await storage.createMemory(memoryData);
      res.json(memory);
    } catch (error) {
      res.status(400).json({ message: 'Invalid memory data', error });
    }
  });

  // Persona state routes
  app.get('/api/persona/:userId', async (req, res) => {
    try {
      const state = await storage.getPersonaState(req.params.userId);
      if (!state) {
        return res.status(404).json({ message: 'Persona state not found' });
      }
      res.json(state);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get persona state' });
    }
  });

  app.patch('/api/persona/:userId', async (req, res) => {
    try {
      const updates = req.body;
      const state = await storage.updatePersonaState(req.params.userId, updates);
      if (!state) {
        return res.status(404).json({ message: 'Persona state not found' });
      }
      res.json(state);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update persona state' });
    }
  });

  // AI Chat endpoint
  app.post('/api/chat', async (req, res) => {
    try {
      const { message, userId, model, mode } = req.body;

      if (!message || !userId || !model) {
        return res.status(400).json({ message: 'Missing required fields' });
      }

      // This would integrate with the SallieBrain system
      // For now, return a basic response structure
      const response = {
        content: "I understand what you're looking for. Let me help you work through this step by step.",
        emotion: "supportive",
        persona: {
          empathy: 92,
          logic: 88,
          creativity: 76
        },
        timestamp: new Date().toISOString()
      };

      res.json(response);
    } catch (error) {
      res.status(500).json({ message: 'Failed to process chat message' });
    }
  });

  return httpServer;
}
