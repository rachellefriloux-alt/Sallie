import { type User, type InsertUser, type Conversation, type InsertConversation, type Task, type InsertTask, type Memory, type InsertMemory, type PersonaState, type InsertPersonaState } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Conversation management
  getConversation(id: string): Promise<Conversation | undefined>;
  getConversationsByUserId(userId: string): Promise<Conversation[]>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversation(id: string, updates: Partial<Conversation>): Promise<Conversation | undefined>;

  // Task management
  getTask(id: string): Promise<Task | undefined>;
  getTasksByUserId(userId: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, updates: Partial<Task>): Promise<Task | undefined>;
  deleteTask(id: string): Promise<boolean>;

  // Memory management
  getMemory(id: string): Promise<Memory | undefined>;
  getMemoriesByUserId(userId: string): Promise<Memory[]>;
  createMemory(memory: InsertMemory): Promise<Memory>;
  updateMemory(id: string, updates: Partial<Memory>): Promise<Memory | undefined>;

  // Persona state management
  getPersonaState(userId: string): Promise<PersonaState | undefined>;
  createPersonaState(state: InsertPersonaState): Promise<PersonaState>;
  updatePersonaState(userId: string, updates: Partial<PersonaState>): Promise<PersonaState | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private conversations: Map<string, Conversation> = new Map();
  private tasks: Map<string, Task> = new Map();
  private memories: Map<string, Memory> = new Map();
  private personaStates: Map<string, PersonaState> = new Map();

  constructor() {
    // Initialize default users
    this.initializeDefaultUsers();
  }

  private async initializeDefaultUsers(): Promise<void> {
    const defaultUsers = [
      {
        username: "you",
        email: "you@example.com",
        firebaseUid: "default-you",
        permissions: { fullAccess: true, memory: true, creativity: true, deviceControl: true, notifications: true, analytics: true },
        profile: { name: "You", avatar: "https://pixabay.com/get/gb5d05698b2a3d1d8af44cd36215543d55b53b18d345d3d712f2e8dfd90881b6bcca03dd0d80a84167e321efcf1ccee8b7a67813a7fcb4824d54890d48da99a74_1280.jpg" }
      },
      {
        username: "austin",
        email: "austin@example.com",
        firebaseUid: "default-austin",
        permissions: { fullAccess: false, memory: false, creativity: true, deviceControl: false, notifications: false, analytics: false },
        profile: { name: "Austin", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" }
      },
      {
        username: "bella",
        email: "bella@example.com",
        firebaseUid: "default-bella",
        permissions: { fullAccess: false, memory: false, creativity: true, deviceControl: false, notifications: false, analytics: false },
        profile: { name: "Bella", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" }
      }
    ];

    for (const userData of defaultUsers) {
      const user = await this.createUser(userData);
      // Create default persona state
      await this.createPersonaState({
        userId: user.id,
        traits: { empathy: 92, logic: 88, creativity: 76 },
        mood: "supportive",
        context: {}
      });
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.firebaseUid === firebaseUid);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      firebaseUid: insertUser.firebaseUid || null,
      permissions: insertUser.permissions || {},
      profile: insertUser.profile || {},
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getConversation(id: string): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async getConversationsByUserId(userId: string): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(conv => conv.userId === userId);
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = randomUUID();
    const conversation: Conversation = {
      ...insertConversation,
      id,
      messages: insertConversation.messages || [],
      metadata: insertConversation.metadata || {},
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async updateConversation(id: string, updates: Partial<Conversation>): Promise<Conversation | undefined> {
    const conversation = this.conversations.get(id);
    if (!conversation) return undefined;
    
    const updatedConversation = { ...conversation, ...updates, updatedAt: new Date() };
    this.conversations.set(id, updatedConversation);
    return updatedConversation;
  }

  async getTask(id: string): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async getTasksByUserId(userId: string): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => task.userId === userId);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = randomUUID();
    const task: Task = {
      ...insertTask,
      id,
      description: insertTask.description || null,
      status: insertTask.status || 'pending',
      priority: insertTask.priority || 'medium',
      dueDate: insertTask.dueDate || null,
      metadata: insertTask.metadata || {},
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: string, updates: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...updates, updatedAt: new Date() };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: string): Promise<boolean> {
    return this.tasks.delete(id);
  }

  async getMemory(id: string): Promise<Memory | undefined> {
    return this.memories.get(id);
  }

  async getMemoriesByUserId(userId: string): Promise<Memory[]> {
    return Array.from(this.memories.values()).filter(memory => memory.userId === userId);
  }

  async createMemory(insertMemory: InsertMemory): Promise<Memory> {
    const id = randomUUID();
    const memory: Memory = {
      ...insertMemory,
      id,
      type: insertMemory.type || 'conversation',
      importance: insertMemory.importance || 'medium',
      tags: insertMemory.tags || [],
      metadata: insertMemory.metadata || {},
      createdAt: new Date(),
    };
    this.memories.set(id, memory);
    return memory;
  }

  async updateMemory(id: string, updates: Partial<Memory>): Promise<Memory | undefined> {
    const memory = this.memories.get(id);
    if (!memory) return undefined;
    
    const updatedMemory = { ...memory, ...updates };
    this.memories.set(id, updatedMemory);
    return updatedMemory;
  }

  async getPersonaState(userId: string): Promise<PersonaState | undefined> {
    return Array.from(this.personaStates.values()).find(state => state.userId === userId);
  }

  async createPersonaState(insertState: InsertPersonaState): Promise<PersonaState> {
    const id = randomUUID();
    const state: PersonaState = {
      ...insertState,
      id,
      traits: insertState.traits || {},
      mood: insertState.mood || 'neutral',
      context: insertState.context || {},
      createdAt: new Date(),
    };
    this.personaStates.set(id, state);
    return state;
  }

  async updatePersonaState(userId: string, updates: Partial<PersonaState>): Promise<PersonaState | undefined> {
    const existingState = await this.getPersonaState(userId);
    if (!existingState) return undefined;
    
    const updatedState = { ...existingState, ...updates };
    this.personaStates.set(existingState.id, updatedState);
    return updatedState;
  }
}

export const storage = new MemStorage();
