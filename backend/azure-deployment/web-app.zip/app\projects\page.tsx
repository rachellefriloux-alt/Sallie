import { ProjectsBrowser } from '@/components/ProjectsBrowser';

export default function ProjectsPage() {
  return (
    <div className="p-6">
      <ProjectsBrowser />
    </div>
  );
}
