'use client';

import { ConvergenceFlow } from '@/components/ConvergenceFlow';

export default function ConvergencePage() {
  return (
    <div className="min-h-screen bg-gray-900">
      <ConvergenceFlow />
    </div>
  );
}

