import { ControlPanel } from '@/components/ControlPanel';

export default function ControlPage() {
  return (
    <div className="p-6">
      <ControlPanel />
    </div>
  );
}
