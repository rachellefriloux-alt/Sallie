from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
import uvicorn
import os
from contextlib import asynccontextmanager
from loguru import logger
from prometheus_client import Counter, Histogram, generate_latest
from starlette.responses import Response
import time

from src.core.config import settings
from src.core.database import engine, Base
from src.api.v1.endpoints import ai, models, health
from src.middleware.auth import AuthMiddleware
from src.middleware.metrics import MetricsMiddleware
from src.middleware.tracing import TracingMiddleware

# Prometheus metrics
REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP requests', ['method', 'endpoint', 'status'])
REQUEST_DURATION = Histogram('http_request_duration_seconds', 'HTTP request duration')

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Python AI Service starting up...")
    # Create database tables
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created")
    yield
    # Shutdown
    logger.info("Python AI Service shutting down...")

# Create FastAPI app
app = FastAPI(
    title="Sallie Studio Python AI Service",
    description="Advanced AI processing with machine learning models",
    version="1.0.0",
    lifespan=lifespan
)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.CORS_ORIGIN or "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(AuthMiddleware)
app.add_middleware(MetricsMiddleware)
app.add_middleware(TracingMiddleware)

@app.middleware("http")
async def prometheus_middleware(request, call_next):
    start_time = time.time()
    response = await call_next(request)
    duration = time.time() - start_time
    
    REQUEST_COUNT.labels(
        method=request.method,
        endpoint=request.url.path,
        status=response.status_code
    ).inc()
    
    REQUEST_DURATION.observe(duration)
    
    return response

# Include routers
app.include_router(health.router, prefix="/health", tags=["health"])
app.include_router(ai.router, prefix="/api/v1/ai", tags=["ai"])
app.include_router(models.router, prefix="/api/v1/models", tags=["models"])

@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type="text/plain")

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    logger.error(f"Global exception: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 3008)),
        reload=True if settings.ENVIRONMENT == "development" else False,
        log_level="info"
    )
